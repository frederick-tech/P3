<#
.SYNOPSIS
    Module de gestion des utilisateurs pour EcoTech Solutions (Multi-Societes & Services)
.DESCRIPTION
    Gere le cycle de vie des utilisateurs :
    - Importation CSV intelligente (mapping Departements -> OU)
    - Gestion dynamique des attributs
    - Creation unitaire
    - Generation automatique des logins
    - Verification de synchronisation CSV <-> AD
.NOTES
    Auteur: Equipe G2
#>

if (-not (Get-Module Module-Common)) {
    Import-Module "$PSScriptRoot\Module-Common.psm1" -ErrorAction Stop
}

#region UTILITAIRES INTERNES

function Get-CSVDelimiter {
    param([string]$Path)
    $firstLine = Get-Content $Path -TotalCount 1
    if ($firstLine -match ";") { return ";" } else { return "," }
}

#endregion

#region 1. IMPORTATION ET GÉNÉRATION DE RAPPORT

function Import-EcoTechUsers {
    [CmdletBinding(SupportsShouldProcess=$true)]
    param(
        [string]$CSVPath = "Fiche_personnels.csv",
        [switch]$UpdateExisting
    )
    
    # Gestion du chemin CSV
    if (-not (Split-Path $CSVPath)) { $CSVPath = Join-Path $PSScriptRoot $CSVPath }
    if (-not (Test-Path $CSVPath)) { 
        Write-Host "Erreur : Fichier CSV introuvable ($CSVPath)" -ForegroundColor Red
        return 
    }

    $config = Get-EcoTechConfig
    $dn = $config.DomainInfo.DN
    $defaultPassword = ConvertTo-SecureString $config.DefaultPassword -AsPlainText -Force
    
    # Lecture du CSV
    $delim = Get-CSVDelimiter -Path $CSVPath
    $users = Import-Csv -Path $CSVPath -Delimiter $delim -Encoding UTF8
    
    # Récupération config stockage (si présente)
    $srvFiles = if ($config.SharesConfig) { $config.SharesConfig.FileServer } else { "FILESERVER" }

    $report = @()
    $total = $users.Count
    $current = 0

    Write-Host "--- IMPORTATION EN COURS ($total utilisateurs) ---" -ForegroundColor Cyan

    foreach ($row in $users) {
        $current++
        Write-Progress -Activity "Importation Active Directory" -Status "Traitement : $($row.Prenom) $($row.Nom)" -PercentComplete (($current / $total) * 100)

        # Initialisation ligne de rapport
        $logEntry = [PSCustomObject]@{
            Nom      = "$($row.Prenom) $($row.Nom)"
            Login    = ""
            Statut   = "Echec"
            Message  = ""
            Date     = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
        }

        try {
            if ([string]::IsNullOrWhiteSpace($row.Nom)) { throw "Nom manquant dans le CSV" }

            # 1. Génération du Login (Nettoyage accents inclus)
            $pClean = Get-CleanString $row.Prenom
            $nClean = Get-CleanString $row.Nom
            $BaseSam = ($pClean.Substring(0,1) + $nClean).ToLower()
            $Sam = $BaseSam

            # 2. Detection homonyme
            $Index = 1
            while (Get-ADUser -Filter "SamAccountName -eq '$Sam'" -ErrorAction SilentlyContinue) {
                if (-not $UpdateExisting) {
                    $Sam = $BaseSam + $Index
                    $Index++
                } else {
                    break 
                }
            }
            $logEntry.Login = $Sam

            # Nettoyage des champs CSV
            $NomDept = if ($row.Departement) { $row.Departement.Trim() } else { "" }
            $NomServ = if ($row.Service)     { $row.Service.Trim() }     else { "" }

            # 4. Mapping Departement (Dxx)
            $CodeDept = if ($config.DepartmentMapping.ContainsKey($NomDept)) { $config.DepartmentMapping[$NomDept] } else { $null }
            
            # 5. Mapping Service (Sxx)
            $CodeServ = if ($NomServ -and $config.ServiceMapping.ContainsKey($NomServ)) { $config.ServiceMapping[$NomServ] } else { $null }
            # Si le mapping retourne une hashtable (selon votre config), on prend le code
            if ($CodeServ -is [hashtable]) { $CodeServ = $CodeServ.Code }

            # 6. Détermination Racine / Site (Logique conservée)
            $RootOU = switch -Wildcard ($row.Societe) {
                "*UBIHard*"       { "UBIHARD" }
                "*Studio Dlight*" { "STUDIODLIGHT" }
                Default           { "ECOTECH" }
            }
            $SiteOU = switch -Wildcard ($row.Site) {
                "*Paris*"  { "PAR" }
                "*Nantes*" { "NTE" }
                Default    { "BDX" }
            }

            # Construction du chemin : UX > Dxx > Sxx
            # Note : On suppose que les Dxx sont dans l'OU UX du site.
            $BasePath = "OU=UX,OU=$SiteOU,OU=$RootOU,$dn"
            
            # Logique hiérarchique : Si on a un CodeDept, on descend dedans. Si on a un CodeServ, on descend encore.
            if ($CodeDept) {
                $PathDept = "OU=$CodeDept,$BasePath"
                # On vérifie/crée l'OU Dept si nécessaire (normalement fait par Module-OU)
                if ($CodeServ) {
                     # Le Service est DANS le département
                    $TargetOU = "OU=$CodeServ,$PathDept"
                } else {
                    $TargetOU = $PathDept
                }
            } else {
                # Fallback si pas de département connu
                $TargetOU = $BasePath 
            }

            # 7. Nettoyage Description Manager (Demande spécifique)
            $RawDesc = "Manager : $($row.'Manager-Prenom') $($row.'Manager-Nom')"
            $CleanDesc = Get-CleanString $RawDesc

            # 8. Parametres AD
            $UserParams = @{
                Name                  = "$($row.Prenom) $($row.Nom)"
                SamAccountName        = $Sam
                DisplayName           = "$($row.Prenom) $($row.Nom)"
                GivenName             = $row.Prenom
                Surname               = $row.Nom
                UserPrincipalName     = "$Sam@$($config.DomainInfo.EmailDomain)"
                Path                  = $TargetOU
                AccountPassword       = $defaultPassword
                Enabled               = $true
                ChangePasswordAtLogon = $true
                Company               = $row.Societe
                Department            = $NomDept
                Title                 = $row.fonction
                OfficePhone           = $row.'Telephone fixe'
                MobilePhone           = $row.'Telephone portable'
                Description           = $CleanDesc # Version sans accents
                HomeDrive             = "I:"
                HomeDirectory         = "\\$srvFiles\Users$\$Sam"
            }

            # 9. Execution
            $existingUser = Get-ADUser -Filter "SamAccountName -eq '$Sam'" -ErrorAction SilentlyContinue
            
            if (-not $existingUser) {
                New-ADUser @UserParams -ErrorAction Stop
                $logEntry.Statut = "Cree"
                $logEntry.Message = "Succès dans $TargetOU"
                # Log silencieux
                Write-EcoLog -Message "User Cree : $Sam" -Level Success -LogOnly
            } elseif ($UpdateExisting) {
                Set-ADUser -Identity $Sam `
                    -Company $row.Societe `
                    -Department $NomDept `
                    -Title $row.fonction `
                    -OfficePhone $row.'Telephone fixe' `
                    -MobilePhone $row.'Telephone portable' `
                    -Description $CleanDesc `
                    -ErrorAction Stop
                
                # Déplacement si l'OU a changé
                if ($existingUser.DistinguishedName -notlike "*$TargetOU") {
                    Move-ADObject -Identity $existingUser.DistinguishedName -TargetPath $TargetOU -ErrorAction SilentlyContinue
                }

                $logEntry.Statut = "Mis a jour"
                $logEntry.Message = "Propriétés actualisées"
                Write-EcoLog -Message "User MAJ : $Sam" -Level Info -LogOnly
            } else {
                $logEntry.Statut = "Existant"
                $logEntry.Message = "Déjà présent, aucune modification"
            }
        } catch {
            $logEntry.Message = $_.Exception.Message
            Write-EcoLog -Message "Erreur $($row.Nom) : $($_.Exception.Message)" -Level Error -LogOnly
        }
        $report += $logEntry
    }

    # Rapport CSV
    $reportDir = Join-Path $PSScriptRoot "Rapports"
    if (-not (Test-Path $reportDir)) { New-Item -ItemType Directory -Path $reportDir -Force | Out-Null }
    $reportFile = Join-Path $reportDir "Rapport_Import_$(Get-Date -Format 'yyyyMMdd_HHmm').csv"
    $report | Export-Csv -Path $reportFile -NoTypeInformation -Delimiter ";" -Encoding UTF8

    # Bilan console
    $crees   = @($report | Where-Object { $_.Statut -eq "Cree" }).Count
    $maj     = @($report | Where-Object { $_.Statut -eq "Mis a jour" }).Count
    $erreurs = @($report | Where-Object { $_.Statut -eq "Echec" }).Count
    
    Write-Host ""
    Write-Host "BILAN : $crees crees | $maj MAJ | $erreurs erreurs" -ForegroundColor Green
    Write-Host "Rapport complet généré : $reportFile" -ForegroundColor Cyan
}

#endregion

#region 2. SYNCHRONISATION (MANAGERS & GROUPES)

function Sync-EcoTechManagers {
    param([string]$CSVPath = "Fiche_personnels.csv")
    
    if (-not (Split-Path $CSVPath)) { $CSVPath = Join-Path $PSScriptRoot $CSVPath }
    if (-not (Test-Path $CSVPath)) { Write-Warning "CSV introuvable"; return }

    $delim = Get-CSVDelimiter -Path $CSVPath
    $users = Import-Csv $CSVPath -Delimiter $delim -Encoding UTF8
    $linked = 0

    Write-Host "--- LIAISON DES MANAGERS ---" -ForegroundColor Cyan

    foreach ($row in $users) {
        if ([string]::IsNullOrWhiteSpace($row.'Manager-Nom')) { continue }

        # On recalcule les logins théoriques
        $uP = Get-CleanString $row.Prenom; $uN = Get-CleanString $row.Nom
        $mP = Get-CleanString $row.'Manager-Prenom'; $mN = Get-CleanString $row.'Manager-Nom'
        
        $userSam = ($uP.Substring(0,1) + $uN).ToLower()
        $mgrSam  = ($mP.Substring(0,1) + $mN).ToLower()

        try {
            $mgrAD = Get-ADUser -Filter "SamAccountName -eq '$mgrSam'" -ErrorAction Stop
            # On vérifie que l'user existe aussi
            if (Get-ADUser -Filter "SamAccountName -eq '$userSam'" -ErrorAction SilentlyContinue) {
                Set-ADUser -Identity $userSam -Manager $mgrAD.DistinguishedName -ErrorAction Stop
                $linked++
                Write-EcoLog -Message "Manager lie : $mgrSam -> $userSam" -Level Info -LogOnly
            }
        } catch {
            # Silencieux ou log only
        }
    }
    Write-Host "Managers lies : $linked" -ForegroundColor Green
}

function Invoke-EcoTechGroupSync {
    <#
    .DESCRIPTION
        Synchronise les utilisateurs AD vers les groupes GRP_Dxx et GRP_Dxx_Sxx
    #>
    Write-Host "--- SYNCHRONISATION GROUPES ---" -ForegroundColor Cyan
    # Appel de la fonction du Module-Groups pour éviter de dupliquer le code
    # Assurez-vous que Module-Groups est chargé
    if (Get-Command Add-UsersToGroups -ErrorAction SilentlyContinue) {
        Add-UsersToGroups
    } else {
        Write-Warning "La fonction Add-UsersToGroups (Module-Groups) est introuvable."
    }
}

#endregion

#region 3. AUDIT ET SYNCHRONISATION

function Compare-EcoTechSync {
    [CmdletBinding()]
    param([string]$CSVPath = "Fiche_personnels.csv")

    $config = Get-EcoTechConfig
    if (-not (Split-Path $CSVPath)) { $CSVPath = Join-Path $PSScriptRoot $CSVPath }
    
    $delim = Get-CSVDelimiter -Path $CSVPath
    $csvUsers = Import-Csv $CSVPath -Delimiter $delim -Encoding UTF8
    $results = @()
    $csvLogins = @()
    $ok = 0; $absent = 0; $desync = 0; $orphelins = 0

    Write-Host "VERIFICATION SYNCHRO CSV <-> AD..." -ForegroundColor Cyan

    foreach ($row in $csvUsers) {
        $uP = Get-CleanString $row.Prenom; $uN = Get-CleanString $row.Nom
        $Sam = ($uP.Substring(0,1) + $uN).ToLower()
        $csvLogins += $Sam

        $adUser = Get-ADUser -Filter "SamAccountName -eq '$Sam'" `
                  -Properties Department, Company, Title, OfficePhone `
                  -ErrorAction SilentlyContinue

        $diffs = @()
        if (-not $adUser) {
            $status = "ABSENT"
            $absent++
        } else {
            # Comparaison souple
            if ($adUser.Department -ne $row.Departement) { $diffs += "Dept" }
            if ($adUser.Title -ne $row.fonction)         { $diffs += "Fonction" }
            
            if ($diffs.Count -gt 0) {
                $status = "DESYNC"
                $desync++
            } else {
                $status = "OK"
                $ok++
            }
        }
        $results += [PSCustomObject]@{ Login = $Sam; Nom = "$($row.Prenom) $($row.Nom)"; Statut = $status }
    }

    # Bilan
    Write-Host "OK: $ok | Desync: $desync | Absent: $absent" -ForegroundColor Green
    
    # Export Audit
    $auditPath = Join-Path $PSScriptRoot "Rapports\Audit_Sync_$(Get-Date -Format 'yyyyMMdd_HHmm').csv"
    $results | Export-Csv -Path $auditPath -NoTypeInformation -Delimiter ";" -Encoding UTF8
    Write-Host "Rapport d'audit : $auditPath"
}

function Show-EcoTechSecurityAudit {
    Clear-Host
    Write-Host "=== AUDIT DE SÉCURITÉ ===" -ForegroundColor Cyan

    $locked = @(Search-ADAccount -LockedOut | Select-Object -First 10)
    Write-Host "Comptes bloques : $($locked.Count)" -ForegroundColor Yellow
    if ($locked) { $locked | Select-Object Name, SamAccountName | Format-Table -AutoSize | Out-Host }

    $limit = (Get-Date).AddDays(-90)
    $inactive = @(
        Get-ADUser -Filter 'Enabled -eq $true' -Properties LastLogonDate |
        Where-Object { $_.LastLogonDate -lt $limit -and $null -ne $_.LastLogonDate } |
        Select-Object -First 10
    )
    Write-Host "Comptes inactifs (>90j) : $($inactive.Count)" -ForegroundColor Red
    if ($inactive) { $inactive | Select-Object Name, LastLogonDate | Format-Table -AutoSize | Out-Host }
}

#endregion

#region 4. OFFBOARDING

function Disable-EcoTechUser {
    param([string]$SamAccountName)
    
    $config = Get-EcoTechConfig
    $date = Get-Date -Format "dd/MM/yyyy"
    $domainDN = $config.DomainInfo.DN
    $archiveOU = "OU=ARCHIVES,$domainDN"

    try {
        $user = Get-ADUser -Identity $SamAccountName -ErrorAction Stop

        if (-not (Get-ADOrganizationalUnit -Filter "Name -eq 'ARCHIVES'" -SearchBase $domainDN -ErrorAction SilentlyContinue)) {
            New-ADOrganizationalUnit -Name "ARCHIVES" -Path $domainDN -Description "Comptes desactives"
        }

        Set-ADObject -Identity $user.DistinguishedName -ProtectedFromAccidentalDeletion $false
        Disable-ADAccount -Identity $SamAccountName
        Set-ADUser -Identity $SamAccountName -Description "PARTI LE $date"
        Move-ADObject -Identity $user.DistinguishedName -TargetPath $archiveOU
        
        Write-Host "Utilisateur $SamAccountName archivé." -ForegroundColor Green
        Write-EcoLog -Message "User Archive : $SamAccountName" -Level Warning

    } catch {
        Write-Host "Erreur : $($_.Exception.Message)" -ForegroundColor Red
    }
}

#endregion

#region 5. MENU

function Show-UserMenu {
    do {
        Clear-Host
        Write-Host "=== GESTION UTILISATEURS (UX) ==="
        Write-Host "1. Importation complète (CSV)"
        Write-Host "2. Synchroniser (Managers & Groupes)"
        Write-Host "3. Audit de cohérence (CSV vs AD)"
        Write-Host "4. Audit de Sécurité (Bloqués / Inactifs)"
        Write-Host "5. Archivage d'un utilisateur"
        Write-Host "6. Déverrouiller un compte"
        Write-Host ""
        Write-Host "Appuyez sur Entrée pour retourner" -ForegroundColor Gray
        
        $c = Read-Host "Choix"
        switch ($c) {
            '1' { 
                $up = Read-Host "Mettre a jour existants ? (O/N)"
                Import-EcoTechUsers -UpdateExisting:($up -eq 'O')
                Pause 
            }
            '2' { Sync-EcoTechManagers; Invoke-EcoTechGroupSync; Pause }
            '3' { Compare-EcoTechSync; Pause }
            '4' { Show-EcoTechSecurityAudit; Pause }
            '5' { 
                $s = Read-Host "Login a archiver"
                if ($s) { Disable-EcoTechUser -SamAccountName $s }
                Pause 
            }
            '6' {
                $s = Read-Host "Login a deverrouiller"
                if ($s) { Unlock-ADAccount $s; Write-Host "OK" -ForegroundColor Green }
                Pause
            }
            ''  { return }
        }
    } while ($c -ne '')
}

#endregion

Export-ModuleMember -Function @(
    'Import-EcoTechUsers',
    'Sync-EcoTechManagers',
    'Invoke-EcoTechGroupSync',
    'Compare-EcoTechSync',
    'Show-EcoTechSecurityAudit',
    'Disable-EcoTechUser',
    'Show-UserMenu'
)
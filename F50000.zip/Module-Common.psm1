<#
.SYNOPSIS
    Module de fonctions communes pour la gestion Active Directory d'EcoTech Solutions

.DESCRIPTION
    Contient les fonctions transverses :
    - Gestion de la configuration
    - Logging centralisé
    - Normalisation des chaînes (Nettoyage d'accents)
    - Génération des Logins (Format: 2 lettres Prénom + Nom)

.NOTES
    Auteur: Équipe G2
#>

#region Variables globales du module

$Script:Config = $null
$Script:LogFile = $null

#endregion

#region 1. FONCTIONS DE MANIPULATION DE TEXTE

function Get-CleanString {
    param([string]$Text)

    # Sécurité : Si le texte est nul ou vide : arrête
    if ([string]::IsNullOrWhiteSpace($Text)) { return "" }

    # 1. Remplacement manuel des ligatures
    $Text = $Text -replace 'œ', 'oe' -replace 'Œ', 'OE' `
                  -replace 'æ', 'ae' -replace 'Æ', 'AE' `
                  -replace 'ß', 'ss' -replace 'ø', 'o' `
                  -replace 'Ø', 'O' `
                  -replace 'ł', 'l' -replace 'Ł', 'L'

    # 2. Normalisation Unicode
    # Ex: 'é' devient 'e' + 'accent'
    $Text = $Text.Normalize([System.Text.NormalizationForm]::FormD)

    # 3. Suppression des accents (Catégorie Mn : Non-Spacing Mark)
    $Text = $Text -replace '\p{Mn}', ''

    # 4. Nettoyage final : Uniquement a-z et 0-9
    # Retrait de tout ce qui n'est pas alphanumérique (espaces, tirets, apostrophes)
    $Text = $Text -replace '[^a-zA-Z0-9]', ''

    # 5. Retour en minuscule
    return $Text.ToLower()
}

function Get-CalculatedLogin {
    <#
    .DESCRIPTION
        Génère la BASE du login (2 lettres prénom + nom).
        La gestion du chiffre (homonyme) se fera dans la boucle d'importation.
    #>
    param(
        [string]$Prenom, 
        [string]$Nom
    )
    
    # 1. Nettoyage individuel de chaque partie (supprime accents et caractères spéciaux)
    $CleanP = Get-CleanString -Text $Prenom
    $CleanN = Get-CleanString -Text $Nom
    
    # 2. Sécurité : Si le prénom nettoyé est trop court (ex: "A"), prendre l'existant
    $P2 = if ($CleanP.Length -ge 2) { $CleanP.Substring(0,2) } else { $CleanP }
    
    # 3. Concaténation de la base
    $BaseLogin = $P2 + $CleanN
    
    # 4. Limitation à 19 caractères. Pour laisser au moins 1 caractère de libre pour l'homonyme (ex: anboutaleb1) sans dépasser la limite AD de 20.
    if ($BaseLogin.Length -gt 19) {
        $BaseLogin = $BaseLogin.Substring(0, 19)
    }

    return $BaseLogin
}

#endregion

#region 2. FONCTIONS DE CONFIGURATION

function Import-EcoTechConfig {
    param([string]$ConfigPath)
    
    if (-not (Test-Path $ConfigPath)) {
        throw "Fichier de configuration introuvable : $ConfigPath"
    }

    try {
        Write-Host "Chargement de la configuration..." 
        
        # 1. Lecture du fichier .psd1
        $RawContent = Get-Content -Path $ConfigPath -Raw -Encoding UTF8
        $Script:Config = Invoke-Expression $RawContent
        
        if (-not ($Script:Config -is [hashtable])) {
            throw "Le fichier n'est pas valide."
        }

        # 2. Détection dynamique du domaine
        # Écrasement des valeurs du fichier par celles de l'AD actuel
        try {
            # Récupèration des infos du domaine courant
            $CurrentAD = Get-ADDomain
            
            Write-Host "Détection de l'environnement Active Directory..."
            
            # Injection des vraies valeurs
            $ad = Get-ADDomain
            $Script:Config.DomainInfo.Name    = $CurrentAD.DNSRoot 
            $Script:Config.DomainInfo.DN      = $CurrentAD.DistinguishedName
            $Script:Config.DomainInfo.NetBIOS = $CurrentAD.NetBIOSName       
            $Script:Config.DomainInfo.EmailDomain = $CurrentAD.DNSRoot
            
            Write-Host "  > Domaine : $($CurrentAD.DNSRoot)" 
            Write-Host "  > Racine  : $($CurrentAD.DistinguishedName)" 
            
        } catch {
            Write-Host "ATTENTION : Impossible de détecter le domaine AD." 
            Write-Host "Le script utilise les valeurs par défaut du fichier config." 
        }

        return $Script:Config

    } catch {
        Write-Host "ERREUR FATALE CONFIG : $($_.Exception.Message)" -ForegroundColor Red
        throw
    }
}

function Get-EcoTechConfig {
    # Retour à la config déjà chargée en mémoire
    if ($null -eq $Script:Config) {
        throw "La configuration n'a pas été chargée. Lancez Import-EcoTechConfig d'abord."
    }
    return $Script:Config
}
#endregion

#region 3. FONCTION DE LOGGING

function Initialize-LogFile {
    param([string]$LogPath)
    $Script:LogFile = $LogPath
    $Dir = Split-Path -Parent $LogPath
    
    if (-not (Test-Path $Dir)) { 
	    New-Item -ItemType Directory -Path $Dir -Force | Out-Null 
	}
    if (-not (Test-Path $LogPath)) { 
	    "Date;Level;Message" | Out-File $LogPath -Encoding UTF8 
	}
}

function Write-EcoLog {
    param(
        [string]$Message,
        [string]$Level = "Info",
        [switch]$LogOnly
    )

    $Date = Get-Date -Format "yyyy-MM-dd HH:mm:ss"

	if ($Script:LogFile) {
        "$Date;$Level;$Message" | Out-File $Script:LogFile -Append -Encoding UTF8
    }

    # 2. Affichage Console (Seulement si -LogOnly n'est pas activé)
    if (-not $LogOnly) {
        $Color = switch ($Level) {
            'Error'   { 'Red' }
            'Success' { 'Green' }
            'Warning' { 'Yellow' }
            Default   { 'Gray' }
        }

    # 3. Écriture dans l'Observateur d'événements Windows
    # Mappage des niveaux du script aux niveaux officiels Windows
	try {
        $EntryType = switch ($Level) { 'Error' { 'Error' } 'Warning' { 'Warning' } Default { 'Information' } }
        Write-EventLog -LogName Application -Source "EcoTechAD" -EntryType $EntryType -EventId 1000 -Message $Message -ErrorAction SilentlyContinue
    } catch {}
}

function Show-StorageMenu {
    Clear-Host
    Write-Host "=== GESTION DU STOCKAGE ===" -ForegroundColor Cyan
    Write-Host "1. Initialiser l'arborescence des dossiers (K: et J:)"
    Write-Host "Q. Retour"
    
    $c = Read-Host "`nChoix"
    if ($c -eq '1') { New-EcoTechSharesStructure; Pause }
}

function Show-EcoTechStatus {
    Write-Host "Domaine: $env:USERDNSDOMAIN | User: $env:USERNAME" 
}

#endregion

# Exporter toutes les fonctions pour qu'elles soient visibles
Export-ModuleMember -Function @(
    'Get-CleanString',
    'Get-CalculatedLogin',
    'Import-EcoTechConfig',
    'Get-EcoTechConfig',
    'Initialize-LogFile',
    'Write-EcoLog',
    'Show-EcoTechStatus'
)
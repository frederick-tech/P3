<#
.SYNOPSIS
    Module de gestion des partages et permissions NTFS - EcoTech
    Cible : Serveur de Fichiers distant (ECO-BDX-EX03)
    
.NOTES
    Auteur: Équipe G2
#>

if (-not (Get-Module Module-Common)) {
    Import-Module "$PSScriptRoot\Module-Common.psm1" -ErrorAction Stop
}

function New-EcoTechSharesStructure {
    [CmdletBinding()]
    param()

    $config = Get-EcoTechConfig
    
    # Récupération des infos dans le Config, ou valeurs par défaut si absentes
    $TargetServer = if ($config.SharesConfig.FileServer) { $config.SharesConfig.FileServer } else { "ECO-BDX-EX03" }
    $RemoteRoot   = if ($config.SharesConfig.RootPath)   { $config.SharesConfig.RootPath }   else { "D:\Partages" }
    $NetBIOS      = $config.DomainInfo.NetBIOS

    Write-Host "Connexion au serveur de fichiers : $TargetServer..." -ForegroundColor Cyan

    # Test de connexion basique
    if (-not (Test-Connection -ComputerName $TargetServer -Count 1 -Quiet)) {
        Write-Host "Erreur : Le serveur $TargetServer est injoignable (Ping)." -ForegroundColor Red
        return
    }

    # --- BLOC D'EXÉCUTION À DISTANCE ---
    # Tout ce qui est dans $ScriptBlock sera exécuté SUR ECO-BDX-EX03
    $Job = Invoke-Command -ComputerName $TargetServer -ArgumentList $RemoteRoot, $config, $NetBIOS -ScriptBlock {
        param($Root, $Cfg, $DomainNetBIOS)

        # Fonction locale au serveur distant pour les logs (simplifiée)
        function LogRemote { param($Msg, $Color="White") Write-Host $Msg -ForegroundColor $Color }

        LogRemote "--- Début configuration sur $env:COMPUTERNAME ---" "Cyan"

        # 1. Création Racine Physique
        if (-not (Test-Path $Root)) {
            New-Item -ItemType Directory -Path $Root -Force | Out-Null
            LogRemote "Racine créée : $Root" "Green"
        }

        # 2. Dossiers Racines & Partages (Cachés $)
        $folders = @("Users", "Services", "Departments")
        foreach ($f in $folders) {
            $p = Join-Path $Root $f
            $sName = "$f`$" # Users$

            if (-not (Test-Path $p)) {
                New-Item -ItemType Directory -Path $p -Force | Out-Null
                LogRemote "Dossier créé : $p" "Green"
            }

            if (-not (Get-SmbShare -Name $sName -ErrorAction SilentlyContinue)) {
                New-SmbShare -Name $sName -Path $p -FullAccess "Tout le monde" -Description "Partage $f EcoTech" | Out-Null
                LogRemote "Partage SMB créé : $sName" "Green"
            }
        }

        # 3. Dossiers Départements (Lecteur K:)
        LogRemote "Vérification des départements..." "Cyan"
        
        foreach ($deptName in $Cfg.DepartmentMapping.Keys) {
            $code = $Cfg.DepartmentMapping[$deptName] # D01
            
            # Note: On refait un nettoyage simple ici car la fonction Get-CleanString n'est pas dispo en remote
            $cleanName = $deptName -replace " ", "" -replace "[éèê]", "e" -replace "[à]", "a" 
            
            $deptPath = Join-Path "$Root\Departments" $deptName # On garde le nom complet pour le dossier physique pour lisibilité
            
            if (-not (Test-Path $deptPath)) {
                New-Item -ItemType Directory -Path $deptPath -Force | Out-Null
                LogRemote "  + Dossier : $deptName" "Green"
            }

            # PERMISSIONS NTFS
            # On construit le nom du groupe attendu
            $GroupName = "GRP_${code}_*" 

            # On tente de trouver le nom exact du groupe via ADSI (méthode compatible sans module AD)
            $Searcher = [adsisearcher]"(sAMAccountName=$GroupName)"
            $Result = $Searcher.FindOne()
            
            if ($Result) {
                $RealGroupName = $Result.Properties["samaccountname"][0]
                $Identity = "$DomainNetBIOS\$RealGroupName"
                
                try {
                    $acl = Get-Acl $deptPath
                    # Règle : Groupe Dxx = Modification
                    $rule = New-Object System.Security.AccessControl.FileSystemAccessRule($Identity, "Modify", "ContainerInherit,ObjectInherit", "None", "Allow")
                    $acl.SetAccessRule($rule)
                    Set-Acl -Path $deptPath -AclObject $acl
                    LogRemote "    > Droits NTFS appliqués pour $RealGroupName" "Gray"
                } catch {
                    LogRemote "    ! Erreur ACL : $($_.Exception.Message)" "Red"
                }
            } else {
                LogRemote "    ! Groupe introuvable pour $code (Vérifiez qu'il est créé)" "Yellow"
            }
        }
    } 
    
    Write-Host "Opération distante terminée." -ForegroundColor Green
    Write-EcoLog -Message "Synchro Stockage sur $TargetServer terminée." -Level Success -LogOnly
}

function Show-StorageMenu {
    do {
        Clear-Host
        Write-Host "=== GESTION STOCKAGE DISTANT ($TargetServer) ==="
        Write-Host "1. Initialiser l'arborescence et les droits sur $TargetServer"
        Write-Host ""
        Write-Host "Appuyez sur Entrée pour retourner" -ForegroundColor Gray
        
        $c = Read-Host "Choix"
        
        switch ($c) {
            '1' { New-EcoTechSharesStructure; Pause }
            ''  { return }
        }
    } while ($c -ne '')
}


# Exporter toutes les fonctions pour qu'elles soient visibles
Export-ModuleMember -Function @(
    'New-EcoTechSharesStructure',
    'Show-StorageMenu',
)
<#
.SYNOPSIS
    Module de gestion des Groupes.

.NOTES
    Auteur: Équipe G2
#>

if (-not (Get-Module Module-Common)) {
    Import-Module "$PSScriptRoot\Module-Common.psm1" -ErrorAction Stop
}

function New-EcoTechAllGroups {
    [CmdletBinding(SupportsShouldProcess=$true)]
    param()

    Clear-Host
    Write-Host "Création des groupes de sécurité..." -ForegroundColor Cyan
    
    try {
        $config = Get-EcoTechConfig
        $DN = $config.DomainInfo.DN
        $SXPath = "OU=SX,OU=BDX,OU=ECOTECH,$DN"

        # Vérification préalable
        if (-not (Get-ADOrganizationalUnit -Identity $SXPath -ErrorAction SilentlyContinue)) {
            Write-Host "Erreur : L'OU 'SX' est introuvable." -ForegroundColor Red
            return
        }

        # --- 1. Groupes DÉPARTEMENTS (Dxx) ---
        # Mapping manuel pour conserver des noms courts
        $ShortNames = @{
            "D01" = "RH"
            "D02" = "COMMERCIAL"
            "D03" = "COMMUNICATION"
            "D04" = "DIRECTION"
            "D05" = "DEV"
            "D06" = "FINANCE"
            "D07" = "DSI"
        }

        $depts = $config.DepartmentMapping
        
        foreach ($deptName in $depts.Keys) {
            $code = $depts[$deptName] # Ex: D01
            
            # Si on a un nom court défini, on l'utilise, sinon on nettoie le nom complet
            if ($ShortNames.ContainsKey($code)) {
                $Suffix = $ShortNames[$code]
            } else {
                $Suffix = (Get-CleanString $deptName) -replace " ", ""
            }

            # Format : GRP_D01_RH
            $GrpName = "GRP_${code}_${Suffix}"
            
            try {
                if (-not (Get-ADGroup -Identity $GrpName -ErrorAction SilentlyContinue)) {
                    if ($PSCmdlet.ShouldProcess($GrpName, "Créer le groupe Département")) {
                        New-ADGroup -Name $GrpName -Path $SXPath -GroupScope Global -GroupCategory Security -Description "Groupe Dept - $deptName"
                        Write-EcoLog -Message "Groupe Dept créé : $GrpName" -Level Success -LogOnly
                    }
                }
            } catch {
                Write-EcoLog -Message "Erreur création $GrpName : $($_.Exception.Message)" -Level Error -LogOnly
            }
        }

        # --- 2. Groupes SERVICES (Dxx_Sxx) ---
        $csvPath = "$PSScriptRoot\Fiche_personnels.csv"
        
        if (Test-Path $csvPath) {
            $csv = Import-Csv $csvPath -Delimiter (Get-CSVDelimiter $csvPath) -Encoding UTF8
            $pairs = $csv | Select-Object Departement, Service -Unique
            $total = $pairs.Count
            $i = 0

            foreach ($item in $pairs) {
                $i++
                Write-Progress -Activity "Création Groupes Services" -Status "$($item.Service)" -PercentComplete (($i / $total) * 100)

                $dCode = $config.DepartmentMapping[$item.Departement]
                $sCode = $config.ServiceMapping[$item.Service]
                # Gestion du cas où ServiceMapping est une Hashtable
                if ($sCode -is [hashtable]) { $sCode = $sCode.Code }

                if ($dCode -and $sCode) {
                    $cleanSuffix = (Get-CleanString $item.Service) -replace " ", ""
                    
                    # Format : GRP_D01_S01_Formation
                    $GrpName = "GRP_${dCode}_${sCode}_${cleanSuffix}"
                    
                    try {
                        if (-not (Get-ADGroup -Identity $GrpName -ErrorAction SilentlyContinue)) {
                            if ($PSCmdlet.ShouldProcess($GrpName, "Créer le groupe Service")) {
                                New-ADGroup -Name $GrpName -Path $SXPath -GroupScope Global -GroupCategory Security -Description "Groupe Service - $($item.Service)"
                                Write-EcoLog -Message "Groupe Service créé : $GrpName" -Level Success -LogOnly
                            }
                        }
                    } catch {
                        Write-EcoLog -Message "Erreur création $GrpName : $($_.Exception.Message)" -Level Error -LogOnly
                    }
                }
            }
        } else {
            Write-Warning "Fichier CSV introuvable pour la structure des services."
        }

        Write-Progress -Activity "Création Groupes Services" -Completed
        Write-Host "Opération terminée." -ForegroundColor Green

    } catch {
        Write-EcoLog -Message "Erreur Module-Groups : $($_.Exception.Message)" -Level Error
    }
}

function Add-UsersToGroups {
    [CmdletBinding(SupportsShouldProcess=$true)]
    param()

    Write-Host "Association automatique des utilisateurs..." -ForegroundColor Cyan
    
    try {
        $config = Get-EcoTechConfig
        $csvPath = "$PSScriptRoot\Fiche_personnels.csv"
        
        if (-not (Test-Path $csvPath)) { Write-Warning "CSV introuvable."; return }

        $users = Import-Csv $csvPath -Delimiter (Get-CSVDelimiter $csvPath) -Encoding UTF8
        $total = $users.Count
        $count = 0

        foreach ($row in $users) {
            $count++
            Write-Progress -Activity "Association Groupes" -Status "Traitement : $($row.Nom)" -PercentComplete (($count / $total) * 100)
            
            # CORRECTION : Recherche par "DisplayName" (Prénom Nom) au lieu de recalculer le SamAccountName.
            # Cela permet de trouver l'utilisateur même si son login est 'pnom1' ou 'pnom2'.
            $FullName = "$($row.Prenom) $($row.Nom)"
            $adUser = Get-ADUser -Filter "Name -eq '$FullName'" -ErrorAction SilentlyContinue
            
            if ($adUser) {
                $codeDept = $config.DepartmentMapping[$row.Departement]
                $valService = $config.ServiceMapping[$row.Service]
                # Gestion Hashtable vs String
                $codeServ = if ($valService -is [hashtable]) { $valService.Code } else { $valService }

                # 1. Groupe DÉPARTEMENT 
                if ($codeDept) {
                    # On cherche un groupe qui commence par GRP_Dxx_
                    $grpD = Get-ADGroup -Filter "Name -like 'GRP_${codeDept}_*'" -ErrorAction SilentlyContinue
                    if ($grpD) { 
                         # Vérifie si déjà membre pour éviter l'erreur
                        $isMember = Get-ADGroupMember -Identity $grpD -Recursive | Where-Object { $_.DistinguishedName -eq $adUser.DistinguishedName }
                        if (-not $isMember) {
                            if ($PSCmdlet.ShouldProcess("$($adUser.Name) -> $($grpD.Name)", "Ajouter membre")) {
                                Add-ADGroupMember -Identity $grpD -Members $adUser -ErrorAction SilentlyContinue 
                                Write-EcoLog -Message "Ajout $($adUser.SamAccountName) -> $($grpD.Name)" -Level Info -LogOnly
                            }
                        }
                    }
                }

                # 2. Groupe SERVICE (GRP_Dxx_Sxx_...)
                if ($codeDept -and $codeServ) {
                    $grpS = Get-ADGroup -Filter "Name -like 'GRP_${codeDept}_${codeServ}_*'" -ErrorAction SilentlyContinue
                    if ($grpS) { 
                        $isMemberS = Get-ADGroupMember -Identity $grpS -Recursive | Where-Object { $_.DistinguishedName -eq $adUser.DistinguishedName }
                        if (-not $isMemberS) {
                            if ($PSCmdlet.ShouldProcess("$($adUser.Name) -> $($grpS.Name)", "Ajouter membre")) {
                                Add-ADGroupMember -Identity $grpS -Members $adUser -ErrorAction SilentlyContinue
                                Write-EcoLog -Message "Ajout $($adUser.SamAccountName) -> $($grpS.Name)" -Level Info -LogOnly
                            }
                        }
                    }
                }
            } else {
                # Log si l'utilisateur du CSV n'est pas trouvé dans l'AD
                Write-EcoLog -Message "Utilisateur introuvable dans l'AD : $FullName" -Level Warning -LogOnly
            }
        }
        Write-Progress -Activity "Association Groupes" -Completed
        Write-Host "Association terminée." -ForegroundColor Green

    } catch {
        Write-EcoLog -Message "Erreur Association : $($_.Exception.Message)" -Level Error
    }
}

function Show-GroupMenu {
    do {
        Clear-Host
        Write-Host "=== GESTION GROUPES (SX) ==="
        Write-Host "1. Créer tous les groupes (Dxx & Dxx_Sxx)"
        Write-Host "2. Associer les utilisateurs aux groupes"
        Write-Host ""
        Write-Host "Appuyez sur Entrée pour retourner" -ForegroundColor Gray

        $c = Read-Host "Choix"
        
        switch ($c) {
            '1' { New-EcoTechAllGroups; Pause }
            '2' { Add-UsersToGroups; Pause }
            ''  { return }
        }
    } while ($c -ne '')
}

# Exporter toutes les fonctions pour qu'elles soient visibles
Export-ModuleMember -Function @(
    'New-EcoTechAllGroups',
    'Show-GroupMenu'
)
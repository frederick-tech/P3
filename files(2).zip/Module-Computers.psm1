<#
.SYNOPSIS
    Module de gestion des Ordinateurs.

.DESCRIPTION
    Gere la creation des objets ordinateur dans l'AD.
    Placement dynamique selon le type de poste (BX/CX/EX/FX).
    
.NOTES
    Auteur: Equipe G2
#>

if (-not (Get-Module Module-Common)) {
    Import-Module "$PSScriptRoot\Module-Common.psm1" -ErrorAction Stop
}

function Import-EcoTechComputers {
    [CmdletBinding()]
    param([string]$CSVPath = "Fiche_personnels.csv")

    # Gestion du chemin
    if (-not (Split-Path $CSVPath)) { $CSVPath = Join-Path $PSScriptRoot $CSVPath }
    if (-not (Test-Path $CSVPath)) {
        Write-Warning "Fichier CSV introuvable : $CSVPath"
        return
    }

    $config = Get-EcoTechConfig
    $dn = $config.DomainInfo.DN
    
    # Lecture CSV
    $delim = Get-CSVDelimiter $CSVPath
    $rows = Import-Csv $CSVPath -Delimiter $delim -Encoding UTF8
    
    $total = $rows.Count
    $i = 0
    $created = 0
    $errors  = 0

    Write-Host "Importation des ordinateurs en cours..." -ForegroundColor Cyan

    foreach ($row in $rows) {
        $i++
        $ComputerName = $row.'Nom de PC'
        Write-Progress -Activity "Importation PC" -Status "Traitement : $ComputerName" -PercentComplete (($i / $total) * 100)

        if ([string]::IsNullOrWhiteSpace($ComputerName)) { continue }

        # Detection Type (BX=Fixe, CX=Portable, par defaut CX)
        $TypeOU = "CX" 
        if ($row.PSObject.Properties.Name -contains "Type") {
             if ($row.Type -like "*Fixe*") { $TypeOU = "BX" }
        }
        
        # Detection Site
        $RootOU = "ECOTECH"; $SiteOU = "BDX"
        if ($row.Societe -like "*UBIHard*")       { $RootOU = "UBIHARD"; $SiteOU = "PAR" }
        if ($row.Societe -like "*Studio Dlight*") { $RootOU = "STUDIODLIGHT"; $SiteOU = "NTE" }
        
        $TargetOU = "OU=$TypeOU,OU=WX,OU=$SiteOU,OU=$RootOU,$dn"

        $Desc = "PC"
        if ($row.Prenom -and $row.Nom) {
            $Desc = "PC de $($row.Prenom) $($row.Nom)"
        }

        try {
            if (-not (Get-ADComputer -Identity $ComputerName -ErrorAction SilentlyContinue)) {
                if (Get-ADOrganizationalUnit -Identity $TargetOU -ErrorAction SilentlyContinue) {
                    New-ADComputer -Name $ComputerName -Path $TargetOU -Description $Desc -Enabled $true
                    Write-EcoLog -Message "PC Cree : $ComputerName ($TypeOU)" -Level Success -LogOnly
                    $created++
                } else {
                    Write-EcoLog -Message "Erreur PC $ComputerName : OU introuvable ($TargetOU)" -Level Error -LogOnly
                    $errors++
                }
            } else {
                Write-EcoLog -Message "PC existe deja : $ComputerName" -Level Warning -LogOnly
            }
        } catch {
            Write-EcoLog -Message "Erreur PC $ComputerName : $($_.Exception.Message)" -Level Error -LogOnly
            $errors++
        }
    }

    Write-Progress -Activity "Importation PC" -Completed
    Write-Host "Bilan : $created crees | $errors erreurs (Voir logs)." -ForegroundColor Green
}

function Show-ComputerMenu {
    do {
        Clear-Host
        Write-Host "=== GESTION ORDINATEURS (WX) ==="
        Write-Host "1. Importer les ordinateurs depuis CSV"
        Write-Host ""
        Write-Host "Appuyez sur Entree pour retourner" -ForegroundColor Gray
        
        $c = Read-Host "Choix"
        
        switch ($c) {
            '1' { Import-EcoTechComputers; Pause }
            ''  { return }
        }
    } while ($c -ne '')
}

Export-ModuleMember -Function @(
    'Import-EcoTechComputers',
    'Show-ComputerMenu'
)

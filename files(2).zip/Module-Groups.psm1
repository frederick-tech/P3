<#
.SYNOPSIS
    Module de gestion des Groupes.

.DESCRIPTION
    Nomenclature des groupes de securite :
      GRP_Dxx_NomDepartement        (ex: GRP_D01_RH)
      GRP_Dxx_Sxx_NomService        (ex: GRP_D02_S01_GestionDesComptes)

.NOTES
    Auteur: Equipe G2
#>

if (-not (Get-Module Module-Common)) {
    Import-Module "$PSScriptRoot\Module-Common.psm1" -ErrorAction Stop
}

function New-EcoTechAllGroups {
    [CmdletBinding(SupportsShouldProcess=$true)]
    param()

    Clear-Host
    Write-Host "Creation des groupes de securite..." -ForegroundColor Cyan
    
    try {
        $config = Get-EcoTechConfig
        $DN = $config.DomainInfo.DN
        $SXPath = "OU=SX,OU=BDX,OU=ECOTECH,$DN"

        # Verification prealable
        if (-not (Get-ADOrganizationalUnit -Identity $SXPath -ErrorAction SilentlyContinue)) {
            Write-Host "Erreur : L'OU 'SX' est introuvable. Lancez la creation des OUs d'abord." -ForegroundColor Red
            return
        }

        # -------------------------------------------------------
        # 1. Groupes DEPARTEMENTS : GRP_Dxx_Suffix
        # -------------------------------------------------------
        Write-Host "--- Groupes Departements ---" -ForegroundColor Cyan

        foreach ($deptName in $config.DepartmentMapping.Keys) {
            $code = $config.DepartmentMapping[$deptName]

            # Suffixe depuis la config (RH, Commercial, etc.)
            if ($config.GroupSuffix -and $config.GroupSuffix.ContainsKey($code)) {
                $Suffix = $config.GroupSuffix[$code]
            } else {
                # Fallback : nettoyage du nom complet
                $Suffix = Get-GroupSuffix -Text $deptName
            }

            $GrpName = "GRP_${code}_${Suffix}"
            $TargetPath = "OU=$code,$SXPath"

            # Verifier que l'OU Dxx existe dans SX
            if (-not (Get-ADOrganizationalUnit -Filter "Name -eq '$code'" -SearchBase $SXPath -ErrorAction SilentlyContinue)) {
                Write-EcoLog -Message "OU $code introuvable dans SX, groupe $GrpName ignore." -Level Warning
                continue
            }

            if (-not (Get-ADGroup -Filter "Name -eq '$GrpName'" -ErrorAction SilentlyContinue)) {
                if ($PSCmdlet.ShouldProcess($GrpName, "Creer le groupe Departement")) {
                    New-ADGroup -Name $GrpName -Path $TargetPath -GroupScope Global -GroupCategory Security -Description "Groupe Dept - $deptName"
                    Write-EcoLog -Message "Groupe Dept cree : $GrpName" -Level Success -LogOnly
                }
            } else {
                Write-EcoLog -Message "Existe deja : $GrpName" -Level Info -LogOnly
            }
        }

        # -------------------------------------------------------
        # 2. Groupes SERVICES : GRP_Dxx_Sxx_Suffix
        # -------------------------------------------------------
        Write-Host "--- Groupes Services ---" -ForegroundColor Cyan

        # Deduplication (ex: "Developpement fronted" et "frontend" = meme D05_S01)
        $seen = @{}

        foreach ($svcName in $config.ServiceMapping.Keys) {
            $svcInfo = $config.ServiceMapping[$svcName]

            # Support ancien format (string) et nouveau (hashtable)
            if ($svcInfo -is [hashtable]) {
                $dCode = $svcInfo.Dept
                $sCode = $svcInfo.Code
            } else {
                # Ancien format sans Dept : on ne peut pas construire le nom complet
                Write-EcoLog -Message "ServiceMapping '$svcName' : format string sans Dept, ignore." -Level Warning
                continue
            }

            $uniqueKey = "${dCode}_${sCode}"
            if ($seen.ContainsKey($uniqueKey)) { continue }
            $seen[$uniqueKey] = $true

            # Suffixe PascalCase du nom de service
            $cleanSuffix = Get-GroupSuffix -Text $svcName
            $GrpName = "GRP_${dCode}_${sCode}_${cleanSuffix}"

            $TargetPath = "OU=$dCode,$SXPath"

            if (-not (Get-ADOrganizationalUnit -Filter "Name -eq '$dCode'" -SearchBase $SXPath -ErrorAction SilentlyContinue)) {
                Write-EcoLog -Message "OU $dCode introuvable dans SX, groupe $GrpName ignore." -Level Warning
                continue
            }

            if (-not (Get-ADGroup -Filter "Name -eq '$GrpName'" -ErrorAction SilentlyContinue)) {
                if ($PSCmdlet.ShouldProcess($GrpName, "Creer le groupe Service")) {
                    New-ADGroup -Name $GrpName -Path $TargetPath -GroupScope Global -GroupCategory Security -Description "Groupe Service - $svcName"
                    Write-EcoLog -Message "Groupe Service cree : $GrpName" -Level Success -LogOnly
                }
            } else {
                Write-EcoLog -Message "Existe deja : $GrpName" -Level Info -LogOnly
            }
        }

        Write-Host "Operation terminee." -ForegroundColor Green

    } catch {
        Write-EcoLog -Message "Erreur Module-Groups : $($_.Exception.Message)" -Level Error
    }
}

function Add-UsersToGroups {
    <#
    .DESCRIPTION
        Associe chaque utilisateur du CSV :
        1. Au groupe departement GRP_Dxx_Suffix
        2. Au groupe service    GRP_Dxx_Sxx_Suffix (si service connu)
    #>
    [CmdletBinding(SupportsShouldProcess=$true)]
    param()

    Write-Host "Association automatique des utilisateurs..." -ForegroundColor Cyan
    
    try {
        $config = Get-EcoTechConfig
        $csvPath = "$PSScriptRoot\Fiche_personnels.csv"
        
        if (-not (Test-Path $csvPath)) { Write-Warning "CSV introuvable."; return }

        $users = Import-Csv $csvPath -Delimiter (Get-CSVDelimiter $csvPath) -Encoding UTF8
        $total = $users.Count
        $count = 0
        $added = 0

        foreach ($row in $users) {
            $count++
            Write-Progress -Activity "Association Groupes" -Status "Traitement : $($row.Nom)" -PercentComplete (($count / $total) * 100)
            
            # Recherche par DisplayName (gere les homonymes pnom1, pnom2)
            $FullName = "$($row.Prenom) $($row.Nom)"
            $adUser = Get-ADUser -Filter "Name -eq '$FullName'" -ErrorAction SilentlyContinue
            
            if (-not $adUser) {
                Write-EcoLog -Message "Utilisateur introuvable dans l'AD : $FullName" -Level Warning -LogOnly
                continue
            }

            $codeDept = $config.DepartmentMapping[$row.Departement]
            $valService = $config.ServiceMapping[$row.Service]
            $codeServ = if ($valService -is [hashtable]) { $valService.Code } else { $valService }

            # ---- 1. Groupe DEPARTEMENT (GRP_Dxx_Suffix) ----
            if ($codeDept) {
                # Construction du nom exact depuis la config
                $deptSuffix = if ($config.GroupSuffix -and $config.GroupSuffix.ContainsKey($codeDept)) {
                    $config.GroupSuffix[$codeDept]
                } else {
                    Get-GroupSuffix -Text $row.Departement
                }
                $grpDeptName = "GRP_${codeDept}_${deptSuffix}"
                $grpD = Get-ADGroup -Filter "Name -eq '$grpDeptName'" -ErrorAction SilentlyContinue

                if ($grpD) { 
                    $isMember = Get-ADGroupMember -Identity $grpD -ErrorAction SilentlyContinue | 
                                Where-Object { $_.DistinguishedName -eq $adUser.DistinguishedName }
                    if (-not $isMember) {
                        if ($PSCmdlet.ShouldProcess("$($adUser.Name) -> $grpDeptName", "Ajouter membre")) {
                            Add-ADGroupMember -Identity $grpD -Members $adUser -ErrorAction SilentlyContinue 
                            Write-EcoLog -Message "Ajout $($adUser.SamAccountName) -> $grpDeptName" -Level Info -LogOnly
                            $added++
                        }
                    }
                }
            }

            # ---- 2. Groupe SERVICE (GRP_Dxx_Sxx_Suffix) ----
            if ($codeDept -and $codeServ) {
                # Wildcard sur le suffixe (tolere les variantes CSV comme "fronted"/"frontend")
                $grpS = Get-ADGroup -Filter "Name -like 'GRP_${codeDept}_${codeServ}_*'" -ErrorAction SilentlyContinue
                if ($grpS) { 
                    $isMemberS = Get-ADGroupMember -Identity $grpS -ErrorAction SilentlyContinue | 
                                 Where-Object { $_.DistinguishedName -eq $adUser.DistinguishedName }
                    if (-not $isMemberS) {
                        if ($PSCmdlet.ShouldProcess("$($adUser.Name) -> $($grpS.Name)", "Ajouter membre")) {
                            Add-ADGroupMember -Identity $grpS -Members $adUser -ErrorAction SilentlyContinue
                            Write-EcoLog -Message "Ajout $($adUser.SamAccountName) -> $($grpS.Name)" -Level Info -LogOnly
                            $added++
                        }
                    }
                }
            }
        }

        Write-Progress -Activity "Association Groupes" -Completed
        Write-Host "Association terminee ($added ajouts)." -ForegroundColor Green

    } catch {
        Write-EcoLog -Message "Erreur Association : $($_.Exception.Message)" -Level Error
    }
}

function Show-GroupMenu {
    do {
        Clear-Host
        Write-Host "=== GESTION GROUPES (SX) ==="
        Write-Host ""
        Write-Host "  Nomenclature : GRP_Dxx_NomDept / GRP_Dxx_Sxx_NomService"
        Write-Host ""
        Write-Host "1. Creer tous les groupes (Dept & Services)"
        Write-Host "2. Associer les utilisateurs aux groupes"
        Write-Host ""
        Write-Host "Appuyez sur Entree pour retourner" -ForegroundColor Gray

        $c = Read-Host "Choix"
        
        switch ($c) {
            '1' { New-EcoTechAllGroups; Pause }
            '2' { Add-UsersToGroups; Pause }
            ''  { return }
        }
    } while ($c -ne '')
}

Export-ModuleMember -Function @(
    'New-EcoTechAllGroups',
    'Add-UsersToGroups',
    'Show-GroupMenu'
)

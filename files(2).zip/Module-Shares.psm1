<#
.SYNOPSIS
    Module de gestion des partages et permissions NTFS - EcoTech
    Cible : Serveur de Fichiers distant (configurable dans SharesConfig)
    
.DESCRIPTION
    Lecteurs :
      I: = Dossier personnel (HomeDrive sur objet User AD)
      J: = Dossier de Service  (script logon)
      K: = Dossier de Departement (script logon)
    Groupes NTFS utilises :
      GRP_Dxx_Suffix         pour K: (Departement)
      GRP_Dxx_Sxx_Suffix     pour J: (Service)

.NOTES
    Auteur: Equipe G2
#>

if (-not (Get-Module Module-Common)) {
    Import-Module "$PSScriptRoot\Module-Common.psm1" -ErrorAction Stop
}

function New-EcoTechSharesStructure {
    [CmdletBinding()]
    param()

    $config = Get-EcoTechConfig
    
    $TargetServer = if ($config.SharesConfig.FileServer) { $config.SharesConfig.FileServer } else { "SVR-FILES" }
    $RemoteRoot   = if ($config.SharesConfig.RootPath)   { $config.SharesConfig.RootPath }   else { "D:\Partages" }
    $NetBIOS      = $config.DomainInfo.NetBIOS

    Write-Host "Connexion au serveur de fichiers : $TargetServer..." -ForegroundColor Cyan

    # Test de connexion
    if (-not (Test-Connection -ComputerName $TargetServer -Count 1 -Quiet)) {
        Write-Host "Erreur : Le serveur $TargetServer est injoignable (Ping)." -ForegroundColor Red
        return
    }

    # --- BLOC D'EXECUTION A DISTANCE ---
    Invoke-Command -ComputerName $TargetServer -ArgumentList $RemoteRoot, $config, $NetBIOS -ScriptBlock {
        param($Root, $Cfg, $DomainNetBIOS)

        function LogRemote { param($Msg, $Color="White") Write-Host $Msg -ForegroundColor $Color }

        LogRemote "--- Debut configuration sur $env:COMPUTERNAME ---" "Cyan"

        # 1. Creation Racine Physique
        if (-not (Test-Path $Root)) {
            New-Item -ItemType Directory -Path $Root -Force | Out-Null
            LogRemote "Racine creee : $Root" "Green"
        }

        # 2. Dossiers Racines & Partages (Caches $)
        $folders = @("Users", "Services", "Departments")
        foreach ($f in $folders) {
            $p = Join-Path $Root $f
            $sName = "$f`$"

            if (-not (Test-Path $p)) {
                New-Item -ItemType Directory -Path $p -Force | Out-Null
                LogRemote "Dossier cree : $p" "Green"
            }

            if (-not (Get-SmbShare -Name $sName -ErrorAction SilentlyContinue)) {
                New-SmbShare -Name $sName -Path $p -FullAccess "$DomainNetBIOS\Admins du domaine" `
                             -ChangeAccess "$DomainNetBIOS\Utilisateurs du domaine" `
                             -Description "Partage $f EcoTech" | Out-Null
                LogRemote "Partage SMB cree : $sName" "Green"
            }
        }

        # -------------------------------------------------------
        # 3. K: Dossiers Departements + NTFS (GRP_Dxx_Suffix)
        # -------------------------------------------------------
        LogRemote "--- Configuration K: (Departements) ---" "Cyan"
        
        foreach ($deptName in $Cfg.DepartmentMapping.Keys) {
            $code = $Cfg.DepartmentMapping[$deptName]
            $deptPath = Join-Path "$Root\Departments" $deptName
            
            if (-not (Test-Path $deptPath)) {
                New-Item -ItemType Directory -Path $deptPath -Force | Out-Null
                LogRemote "  + Dossier K: $deptName" "Green"
            }

            # Construction du nom de groupe exact depuis GroupSuffix
            $suffix = $null
            if ($Cfg.GroupSuffix -and $Cfg.GroupSuffix.ContainsKey($code)) {
                $suffix = $Cfg.GroupSuffix[$code]
            }
            
            if ($suffix) {
                $GroupName = "GRP_${code}_${suffix}"
                
                # Recherche du groupe via ADSI
                $Searcher = [adsisearcher]"(&(objectCategory=group)(sAMAccountName=$GroupName))"
                $Result = $Searcher.FindOne()
                
                if ($Result) {
                    $Identity = "$DomainNetBIOS\$GroupName"
                    try {
                        $acl = Get-Acl $deptPath
                        $rule = New-Object System.Security.AccessControl.FileSystemAccessRule(
                            $Identity, "Modify", "ContainerInherit,ObjectInherit", "None", "Allow"
                        )
                        $acl.SetAccessRule($rule)
                        Set-Acl -Path $deptPath -AclObject $acl
                        LogRemote "    > NTFS K: $GroupName -> Modify" "Gray"
                    } catch {
                        LogRemote "    ! Erreur ACL K: $($_.Exception.Message)" "Red"
                    }
                } else {
                    LogRemote "    ! Groupe $GroupName introuvable (creez les groupes d'abord)" "Yellow"
                }
            }
        }

        # -------------------------------------------------------
        # 4. J: Dossiers Services + NTFS (GRP_Dxx_Sxx_Suffix)
        # -------------------------------------------------------
        LogRemote "--- Configuration J: (Services) ---" "Cyan"

        $seenSvc = @{}

        foreach ($svcName in $Cfg.ServiceMapping.Keys) {
            $svcInfo = $Cfg.ServiceMapping[$svcName]

            if ($svcInfo -is [hashtable]) {
                $dCode = $svcInfo.Dept
                $sCode = $svcInfo.Code
            } else {
                continue
            }

            $uniqueKey = "${dCode}_${sCode}"
            if ($seenSvc.ContainsKey($uniqueKey)) { continue }
            $seenSvc[$uniqueKey] = $true

            $svcPath = Join-Path "$Root\Services" $svcName

            if (-not (Test-Path $svcPath)) {
                New-Item -ItemType Directory -Path $svcPath -Force | Out-Null
                LogRemote "  + Dossier J: $svcName" "Green"
            }

            # Recherche du groupe par pattern GRP_Dxx_Sxx_*
            $pattern = "GRP_${dCode}_${sCode}_*"
            $Searcher = [adsisearcher]"(&(objectCategory=group)(sAMAccountName=$pattern))"
            $Result = $Searcher.FindOne()

            if ($Result) {
                $RealGroupName = $Result.Properties["samaccountname"][0]
                $Identity = "$DomainNetBIOS\$RealGroupName"
                try {
                    $acl = Get-Acl $svcPath
                    $rule = New-Object System.Security.AccessControl.FileSystemAccessRule(
                        $Identity, "Modify", "ContainerInherit,ObjectInherit", "None", "Allow"
                    )
                    $acl.SetAccessRule($rule)
                    Set-Acl -Path $svcPath -AclObject $acl
                    LogRemote "    > NTFS J: $RealGroupName -> Modify" "Gray"
                } catch {
                    LogRemote "    ! Erreur ACL J: $($_.Exception.Message)" "Red"
                }
            } else {
                LogRemote "    ! Groupe $pattern introuvable (creez les groupes d'abord)" "Yellow"
            }
        }
    } 
    
    Write-Host "Operation distante terminee." -ForegroundColor Green
    Write-EcoLog -Message "Synchro Stockage sur $TargetServer terminee." -Level Success -LogOnly
}

function New-EcoTechLogonScript {
    <#
    .DESCRIPTION
        Genere le script de logon EcoTech-MapDrives.bat + helpers VBS dans NETLOGON.
        K: mappe depuis l'attribut AD "Department"
        J: mappe depuis l'appartenance au groupe GRP_Dxx_Sxx_*
    #>
    [CmdletBinding()]
    param()

    $config = Get-EcoTechConfig
    $server = $config.SharesConfig.FileServer
    $svcShare = $config.SharesConfig.ServicesShare
    $deptShare = $config.SharesConfig.DeptShare

    $netlogon = "\\$($config.DomainInfo.Name)\NETLOGON"

    if (-not (Test-Path $netlogon)) {
        Write-EcoLog -Message "NETLOGON introuvable : $netlogon" -Level Error
        return
    }

    # --- BAT principal ---
    $batContent = @"
@echo off
REM =====================================================
REM EcoTech Solutions - Mappage lecteurs J: et K:
REM I: = HomeDrive (gere par AD, pas besoin de script)
REM =====================================================

net use J: /delete /yes 2>nul
net use K: /delete /yes 2>nul

REM --- K: Departement (depuis attribut AD Department) ---
for /f "tokens=*" %%D in ('cscript //nologo "%~dp0GetDept.vbs"') do set USERDEPT=%%D

if defined USERDEPT (
    net use K: "\\$server\$deptShare\%USERDEPT%" /persistent:no 2>nul
)

REM --- J: Service (depuis appartenance groupe GRP_Dxx_Sxx_*) ---
for /f "tokens=*" %%S in ('cscript //nologo "%~dp0GetSvc.vbs"') do set USERSVC=%%S

if defined USERSVC (
    net use J: "\\$server\$svcShare\%USERSVC%" /persistent:no 2>nul
)
"@

    # --- VBS : lecture attribut Department ---
    $vbsDept = @"
On Error Resume Next
Set objSysInfo = CreateObject("ADSystemInfo")
Set objUser = GetObject("LDAP://" & objSysInfo.UserName)
WScript.Echo objUser.Department
"@

    # --- VBS : lecture Description du groupe service ---
    # Parcourt les groupes de l'utilisateur, trouve GRP_Dxx_Sxx_*
    # et retourne la Description du groupe (= nom du service original)
    $vbsSvc = @"
On Error Resume Next
Set objSysInfo = CreateObject("ADSystemInfo")
Set objUser = GetObject("LDAP://" & objSysInfo.UserName)
arrGroups = objUser.memberOf

If IsArray(arrGroups) Then
    For Each grpDN In arrGroups
        Set objGroup = GetObject("LDAP://" & grpDN)
        grpName = objGroup.CN
        ' Detecte les groupes service : GRP_Dxx_Sxx_*
        If Left(grpName, 4) = "GRP_" Then
            parts = Split(grpName, "_")
            If UBound(parts) >= 3 Then
                ' C'est un groupe service -> retourne la Description (nom du service)
                desc = objGroup.Description
                If InStr(desc, "Groupe Service - ") > 0 Then
                    WScript.Echo Mid(desc, 18)
                    WScript.Quit 0
                End If
            End If
        End If
    Next
End If
"@

    try {
        $batContent | Out-File -FilePath (Join-Path $netlogon "EcoTech-MapDrives.bat") -Encoding ASCII -Force
        $vbsDept    | Out-File -FilePath (Join-Path $netlogon "GetDept.vbs") -Encoding ASCII -Force
        $vbsSvc     | Out-File -FilePath (Join-Path $netlogon "GetSvc.vbs") -Encoding ASCII -Force

        Write-EcoLog -Message "Script logon deploye dans NETLOGON" -Level Success
        Write-Host "  Fichiers dans NETLOGON :" -ForegroundColor Cyan
        Write-Host "    - EcoTech-MapDrives.bat"
        Write-Host "    - GetDept.vbs"
        Write-Host "    - GetSvc.vbs"
        Write-Host ""
        Write-Host "  Activation : GPO > Config User > Logon Script" -ForegroundColor Yellow
        Write-Host "  Ou : Set-ADUser -ScriptPath 'EcoTech-MapDrives.bat'" -ForegroundColor Yellow

    } catch {
        Write-EcoLog -Message "Erreur deploiement logon : $($_.Exception.Message)" -Level Error
    }
}

function Show-StorageMenu {
    do {
        Clear-Host
        Write-Host "=== GESTION STOCKAGE (I: J: K:) ===" -ForegroundColor Cyan
        Write-Host ""
        Write-Host "  I: Dossier personnel  -> HomeDrive (import CSV)"
        Write-Host "  J: Dossier de service -> Script logon + NTFS"
        Write-Host "  K: Dossier de dept    -> Script logon + NTFS"
        Write-Host ""
        Write-Host "1. Deployer les partages SMB + NTFS sur serveur distant"
        Write-Host "2. Generer le script de logon (J: et K:)"
        Write-Host ""
        Write-Host "Appuyez sur Entree pour retourner" -ForegroundColor Gray
        
        $c = Read-Host "Choix"
        
        switch ($c) {
            '1' { New-EcoTechSharesStructure; Pause }
            '2' { New-EcoTechLogonScript; Pause }
            ''  { return }
        }
    } while ($c -ne '')
}

Export-ModuleMember -Function @(
    'New-EcoTechSharesStructure',
    'New-EcoTechLogonScript',
    'Show-StorageMenu'
)

<#
.SYNOPSIS
    Module de fonctions communes pour la gestion Active Directory d'EcoTech Solutions

.DESCRIPTION
    Contient les fonctions transverses :
    - Gestion de la configuration
    - Logging centralise
    - Normalisation des chaines (Nettoyage d'accents)
    - Generation des Logins (Format: 1 lettre Prenom + Nom)
    - Nettoyage pour noms de groupes (PascalCase)
    - Detection delimiter CSV

.NOTES
    Auteur: Equipe G2
#>

#region Variables globales du module

$Script:Config = $null
$Script:LogFile = $null

#endregion

#region 1. FONCTIONS DE MANIPULATION DE TEXTE

function Get-CleanString {
    param([string]$Text)

    if ([string]::IsNullOrWhiteSpace($Text)) { return "" }

    # 1. Remplacement manuel des ligatures
    $Text = $Text -replace 'œ', 'oe' -replace 'Œ', 'OE' `
                  -replace 'æ', 'ae' -replace 'Æ', 'AE' `
                  -replace 'ß', 'ss' -replace 'ø', 'o' `
                  -replace 'Ø', 'O' `
                  -replace 'ł', 'l' -replace 'Ł', 'L'

    # 2. Normalisation Unicode (e accent -> e + accent)
    $Text = $Text.Normalize([System.Text.NormalizationForm]::FormD)

    # 3. Suppression des accents (Categorie Mn : Non-Spacing Mark)
    $Text = $Text -replace '\p{Mn}', ''

    # 4. Nettoyage final : Uniquement a-z et 0-9
    $Text = $Text -replace '[^a-zA-Z0-9]', ''

    # 5. Retour en minuscule
    return $Text.ToLower()
}

function Get-GroupSuffix {
    <#
    .DESCRIPTION
        Nettoie un nom pour l'utiliser comme suffixe dans un nom de groupe AD.
        Resultat : PascalCase, sans accents, sans espaces, sans caracteres speciaux.
        Conserve les acronymes courts (B2B, ADV, DSI, RH).
        Exemples :
          "Formation"              -> "Formation"
          "Gestion des comptes"    -> "GestionDesComptes"
          "Développement frontend" -> "DeveloppementFrontend"
          "B2B"                    -> "B2B"
    #>
    param([string]$Text)

    if ([string]::IsNullOrWhiteSpace($Text)) { return "" }

    # 1. Ligatures
    $Text = $Text -replace 'œ','oe' -replace 'Œ','OE' -replace 'æ','ae' -replace 'Æ','AE'

    # 2. Suppression accents (Unicode normalization)
    $Text = $Text.Normalize([System.Text.NormalizationForm]::FormD)
    $Text = $Text -replace '\p{Mn}',''

    # 3. PascalCase par mot
    $words = $Text -split '\s+'
    $result = foreach ($w in $words) {
        if ($w.Length -eq 0) { continue }
        # Garder les acronymes intacts (ex: B2B, ADV, DSI, RH)
        if ($w -cmatch '^[A-Z0-9]+$' -and $w.Length -le 4) {
            $w
        } else {
            $w.Substring(0,1).ToUpper() + $w.Substring(1)
        }
    }

    # 4. Joindre et nettoyer les caracteres non-alphanumeriques restants
    return (($result -join '') -replace '[^a-zA-Z0-9]','')
}

function Get-CalculatedLogin {
    <#
    .DESCRIPTION
        Genere la BASE du login (2 lettres prenom + nom).
        La gestion du chiffre (homonyme) se fera dans la boucle d'importation.
    #>
    param(
        [string]$Prenom, 
        [string]$Nom
    )
    
    $CleanP = Get-CleanString -Text $Prenom
    $CleanN = Get-CleanString -Text $Nom
    
    # Securite : Si le prenom nettoye est trop court
    $P2 = if ($CleanP.Length -ge 2) { $CleanP.Substring(0,2) } else { $CleanP }
    
    $BaseLogin = $P2 + $CleanN
    
    # Limitation a 19 caracteres (reserve 1 char pour homonyme, max AD = 20)
    if ($BaseLogin.Length -gt 19) {
        $BaseLogin = $BaseLogin.Substring(0, 19)
    }

    return $BaseLogin
}

function Get-CSVDelimiter {
    <#
    .DESCRIPTION
        Detecte automatiquement le delimiteur d'un fichier CSV (virgule ou point-virgule).
    #>
    param([string]$Path)
    $firstLine = Get-Content $Path -TotalCount 1
    if ($firstLine -match ";") { return ";" } else { return "," }
}

#endregion

#region 2. FONCTIONS DE CONFIGURATION

function Import-EcoTechConfig {
    param([string]$ConfigPath)
    
    if (-not (Test-Path $ConfigPath)) {
        throw "Fichier de configuration introuvable : $ConfigPath"
    }

    try {
        Write-Host "Chargement de la configuration..." 
        
        # 1. Lecture du fichier .psd1
        $RawContent = Get-Content -Path $ConfigPath -Raw -Encoding UTF8
        $Script:Config = Invoke-Expression $RawContent
        
        if (-not ($Script:Config -is [hashtable])) {
            throw "Le fichier n'est pas valide."
        }

        # 2. Detection dynamique du domaine
        try {
            $CurrentAD = Get-ADDomain
            
            Write-Host "Detection de l'environnement Active Directory..."
            
            $Script:Config.DomainInfo.Name    = $CurrentAD.DNSRoot 
            $Script:Config.DomainInfo.DN      = $CurrentAD.DistinguishedName
            $Script:Config.DomainInfo.NetBIOS = $CurrentAD.NetBIOSName       
            $Script:Config.DomainInfo.EmailDomain = $CurrentAD.DNSRoot
            
            Write-Host "  > Domaine : $($CurrentAD.DNSRoot)" 
            Write-Host "  > Racine  : $($CurrentAD.DistinguishedName)" 
            
        } catch {
            Write-Host "ATTENTION : Impossible de detecter le domaine AD." 
            Write-Host "Le script utilise les valeurs par defaut du fichier config." 
        }

        return $Script:Config

    } catch {
        Write-Host "ERREUR FATALE CONFIG : $($_.Exception.Message)" -ForegroundColor Red
        throw
    }
}

function Get-EcoTechConfig {
    if ($null -eq $Script:Config) {
        throw "La configuration n'a pas ete chargee. Lancez Import-EcoTechConfig d'abord."
    }
    return $Script:Config
}
#endregion

#region 3. FONCTION DE LOGGING

function Initialize-LogFile {
    param([string]$LogPath)
    $Script:LogFile = $LogPath
    $Dir = Split-Path -Parent $LogPath
    
    if (-not (Test-Path $Dir)) { 
        New-Item -ItemType Directory -Path $Dir -Force | Out-Null 
    }
    if (-not (Test-Path $LogPath)) { 
        "Date;Level;Message" | Out-File $LogPath -Encoding UTF8 
    }
}

function Write-EcoLog {
    param(
        [string]$Message,
        [string]$Level = "Info",
        [switch]$LogOnly
    )

    $Date = Get-Date -Format "yyyy-MM-dd HH:mm:ss"

    # 1. Ecriture dans le fichier de log
    if ($Script:LogFile) {
        "$Date;$Level;$Message" | Out-File $Script:LogFile -Append -Encoding UTF8
    }

    # 2. Affichage Console (Seulement si -LogOnly n'est pas active)
    if (-not $LogOnly) {
        $Color = switch ($Level) {
            'Error'   { 'Red' }
            'Success' { 'Green' }
            'Warning' { 'Yellow' }
            Default   { 'Gray' }
        }
        Write-Host "[$Level] $Message" -ForegroundColor $Color
    }

    # 3. Ecriture dans l'Observateur d'evenements Windows
    try {
        $EntryType = switch ($Level) { 'Error' { 'Error' } 'Warning' { 'Warning' } Default { 'Information' } }
        Write-EventLog -LogName Application -Source "EcoTechAD" -EntryType $EntryType -EventId 1000 -Message $Message -ErrorAction SilentlyContinue
    } catch {}
}

function Show-EcoTechStatus {
    Write-Host "Domaine: $env:USERDNSDOMAIN | User: $env:USERNAME" 
}

#endregion

Export-ModuleMember -Function @(
    'Get-CleanString',
    'Get-GroupSuffix',
    'Get-CalculatedLogin',
    'Get-CSVDelimiter',
    'Import-EcoTechConfig',
    'Get-EcoTechConfig',
    'Initialize-LogFile',
    'Write-EcoLog',
    'Show-EcoTechStatus'
)

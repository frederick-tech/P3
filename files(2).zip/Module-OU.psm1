<#
.SYNOPSIS
    Module de gestion des OUs (Architecture).

.NOTES
    Auteur: Equipe G2
#>

if (-not (Get-Module Module-Common)) {
    Import-Module "$PSScriptRoot\Module-Common.psm1" -ErrorAction Stop
}

function New-EcoTechOUStructure {
    [CmdletBinding(SupportsShouldProcess=$true)]
    param()
    
    Clear-Host
    Write-Host "Initialisation de l'architecture Active Directory..." -ForegroundColor Cyan
    
    try {
        $config = Get-EcoTechConfig
        $domainDN = $config.DomainInfo.DN
        
        # --- PHASE 1 : Structure de base (Depuis le fichier Config) ---
        $total = $config.OUStructure.Count
        $i = 0

        foreach ($ou in $config.OUStructure) {
            $i++
            Write-Progress -Activity "Architecture de base" -Status "Traitement : $($ou.Name)" -PercentComplete (($i / $total) * 100)

            $Path = if ([string]::IsNullOrWhiteSpace($ou.Parent)) { $domainDN } else { "$($ou.Parent),$domainDN" }
            $TargetOU = "OU=$($ou.Name),$Path"
            
            if (-not (Get-ADOrganizationalUnit -Identity $TargetOU -ErrorAction SilentlyContinue)) {
                New-ADOrganizationalUnit -Name $ou.Name -Path $Path -Description $ou.Description -ProtectedFromAccidentalDeletion $true
                Write-EcoLog -Message "OU Base Creee : $($ou.Name)" -Level Success -LogOnly
            }
        }
        Write-Progress -Activity "Architecture de base" -Completed

        # --- PHASE 2 : Creation dynamique des Services (Sxx) ---
        Write-Host "Verification des Services (Sxx)..." -ForegroundColor Cyan
        
        $CSVPath = "$PSScriptRoot\Fiche_personnels.csv"
        
        if (Test-Path $CSVPath) {
            # Detection delimiteur automatique
            $delim = Get-CSVDelimiter -Path $CSVPath
            
            $csv = Import-Csv $CSVPath -Delimiter $delim -Encoding UTF8
            $structure = $csv | Select-Object Departement, Service -Unique
            $totalS = $structure.Count
            $j = 0

            foreach ($item in $structure) {
                $j++
                Write-Progress -Activity "Architecture Services" -Status "$($item.Service)" -PercentComplete (($j / $totalS) * 100)

                $CodeDept = $config.DepartmentMapping[$item.Departement]
                $ValService = $config.ServiceMapping[$item.Service]
                # Gestion si le mapping est une Hashtable ou un String
                $CodeService = if ($ValService -is [hashtable]) { $ValService.Code } else { $ValService }
                
                if ($CodeDept -and $CodeService) {
                    $ParentPath = "OU=$CodeDept,OU=UX,OU=BDX,OU=ECOTECH,$domainDN"

                    if (Get-ADOrganizationalUnit -Identity $ParentPath -ErrorAction SilentlyContinue) {
                        $TargetSxx = "OU=$CodeService,$ParentPath"
                        
                        if (-not (Get-ADOrganizationalUnit -Identity $TargetSxx -ErrorAction SilentlyContinue)) {
                            New-ADOrganizationalUnit -Name $CodeService -Path $ParentPath -Description $item.Service -ProtectedFromAccidentalDeletion $true
                            Write-EcoLog -Message "OU Service Creee : $CodeService ($($item.Service)) dans $CodeDept" -Level Success -LogOnly
                        }
                    }
                }
            }
            Write-Progress -Activity "Architecture Services" -Completed
        } else {
            Write-Warning "Fichier CSV introuvable. Les OUs de services (Sxx) n'ont pas pu etre verifiees."
        }
        
        Write-Host "Architecture mise a jour avec succes." -ForegroundColor Green
        Write-EcoLog -Message "Mise a jour architecture terminee." -Level Info -LogOnly

    } catch {
        Write-Host "Erreur critique : $($_.Exception.Message)" -ForegroundColor Red
        Write-EcoLog -Message "Erreur Structure OU : $($_.Exception.Message)" -Level Error
    }
}

function Remove-EcoTechEntireInfrastructure {
    param()
    
    $confirm = Read-Host "Etes-vous SUR de vouloir TOUT supprimer ? (OUI/NON)"
    if ($confirm -eq "OUI") {
        $config = Get-EcoTechConfig
        $domainDN = $config.DomainInfo.DN
        
        # Racines principales + Archives
        $Roots = @("ECOTECH", "UBIHARD", "STUDIODLIGHT", "ARCHIVES") 
        
        foreach ($root in $Roots) {
            $Target = "OU=$root,$domainDN"
            if (Get-ADOrganizationalUnit -Identity $Target -ErrorAction SilentlyContinue) {
                Write-Host "Suppression de $root..." -ForegroundColor Yellow
                # Deproteger recursivement
                Get-ADOrganizationalUnit -SearchBase $Target -Filter * | Set-ADObject -ProtectedFromAccidentalDeletion $false
                Remove-ADOrganizationalUnit -Identity $Target -Recursive -Confirm:$false
                Write-EcoLog -Message "Suppression racine : $root" -Level Warning -LogOnly
            }
        }
        Write-Host "Suppression terminee." -ForegroundColor Red
    }
}

function Show-OUMenu {
    do {
        Clear-Host
        Write-Host "=== GESTION DE L'ARCHITECTURE ==="
        Write-Host "1. Initialiser/Mettre a jour toute l'infrastructure"
        Write-Host "2. [DANGER] Supprimer toute l'infrastructure"
        Write-Host ""
        Write-Host "Appuyez sur Entree pour retourner" -ForegroundColor Gray
        
        $c = Read-Host "Choix"
        
        switch ($c) {
            '1' { New-EcoTechOUStructure; Pause }
            '2' { Remove-EcoTechEntireInfrastructure; Pause }
            ''  { return } 
        }
    } while ($c -ne '')
}

Export-ModuleMember -Function @(
    'New-EcoTechOUStructure',
    'Remove-EcoTechEntireInfrastructure',
    'Show-OUMenu'
)

<#
.SYNOPSIS
    Gestionnaire Active Directory - EcoTech Solutions
.DESCRIPTION
    Point d'entree principal. Charge tous les modules et affiche le menu.
.NOTES
    Mise a jour : Integration Module-Shares + Gestion Logs
#>

[CmdletBinding()]
param()

# ----------------------------------------------------------------
# 1. INITIALISATION DE L'ENVIRONNEMENT
# ----------------------------------------------------------------

# Encodage UTF-8 pour les accents
try { [Console]::OutputEncoding = [System.Text.Encoding]::UTF8 } catch {}

# Detection du chemin du script
if ($PSScriptRoot) {
    $ScriptRoot = $PSScriptRoot
} elseif ($MyInvocation.MyCommand.Path) {
    $ScriptRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
} else {
    $ScriptRoot = Get-Location
}

Write-Host "Demarrage EcoTech AD Manager..." -ForegroundColor Cyan
Write-Host "Chemin racine : $ScriptRoot" -ForegroundColor Gray

# ----------------------------------------------------------------
# 2. CHARGEMENT DES MODULES
# ----------------------------------------------------------------

$modules = @(
    "Module-Common.psm1",
    "Module-OU.psm1",
    "Module-Groups.psm1",
    "Module-Users.psm1",
    "Module-Computers.psm1",
    "Module-Shares.psm1" 
)

try {
    foreach ($mod in $modules) {
        $modPath = Join-Path -Path $ScriptRoot -ChildPath $mod
        
        Write-Host "Chargement de $mod..." -NoNewline
        
        if (Test-Path $modPath) {
            Import-Module $modPath -ErrorAction Stop -Force
            Write-Host " OK" -ForegroundColor Green
        } else {
            Write-Host " MANQUANT" -ForegroundColor Red
            throw "Le module $mod est introuvable dans $ScriptRoot"
        }
    }
} catch {
    Write-Host "`nERREUR CRITIQUE : $($_.Exception.Message)" -ForegroundColor Red
    Read-Host "Appuyez sur Entree pour quitter"
    exit
}

# ----------------------------------------------------------------
# 3. CONFIGURATION & LOGS
# ----------------------------------------------------------------

try {
    # 1. Chargement Config
    $ConfigPath = Join-Path -Path $ScriptRoot -ChildPath "Config-EcoTechAD.psd1"
    if (-not (Test-Path $ConfigPath)) { throw "Fichier de configuration introuvable." }
    
    Import-EcoTechConfig -ConfigPath $ConfigPath
    
    # 2. Initialisation des Logs
    $LogDir = Join-Path -Path $ScriptRoot -ChildPath "Logs"
    if (-not (Test-Path $LogDir)) { New-Item -ItemType Directory -Path $LogDir -Force | Out-Null }
    
    $LogFile = Join-Path $LogDir "EcoTech_$(Get-Date -Format 'yyyy-MM-dd').log"
    
    # Injection du LogFile dans le scope du module Common
    $commonModule = Get-Module Module-Common
    if ($commonModule) {
        & $commonModule Set-Variable -Name LogFile -Value $LogFile -Scope Script
    }

    Write-Host "Configuration chargee. Logs : $LogFile" -ForegroundColor Gray

} catch {
    Write-Host "Erreur d'initialisation : $($_.Exception.Message)" -ForegroundColor Red
    Read-Host "Appuyez sur Entree pour quitter"
    exit
}

# ----------------------------------------------------------------
# 4. MENU PRINCIPAL
# ----------------------------------------------------------------

function Show-MainMenu {
    Clear-Host
    Write-Host "========================================================" -ForegroundColor Cyan
    Write-Host "             ECOTECH SOLUTIONS - MANAGER AD             " -ForegroundColor White
    Write-Host "========================================================" -ForegroundColor Cyan
    
    if (Get-Command Show-EcoTechStatus -ErrorAction SilentlyContinue) {
        Show-EcoTechStatus
    }
    
    Write-Host ""
    Write-Host "1. Gestion OUs (Architecture)"
    Write-Host "2. Gestion Groupes (SX)"
    Write-Host "3. Gestion Utilisateurs (UX)"
    Write-Host "4. Gestion Ordinateurs (WX)"
    Write-Host "5. Gestion Stockage (I, J, K)"
    Write-Host "Q. Quitter" 
    Write-Host ""
    
    $choice = Read-Host "Votre choix"
    
    switch ($choice) {
        '1' { Show-OUMenu }
        '2' { Show-GroupMenu }
        '3' { Show-UserMenu }
        '4' { Show-ComputerMenu }
        '5' { Show-StorageMenu }
        'Q' { return 'Q' }
        Default { Write-Host "Choix invalide." -ForegroundColor Red; Start-Sleep -Seconds 1 }
    }
}

# ----------------------------------------------------------------
# 5. EXECUTION
# ----------------------------------------------------------------

do {
    $action = Show-MainMenu
} while ($action -ne 'Q')

Write-Host "Fermeture de l'application..." -ForegroundColor Yellow
Start-Sleep -Seconds 1

<#
.SYNOPSIS
    Module de gestion des OUs.
#>

if (-not (Get-Module Module-Common)) {
    Import-Module "$PSScriptRoot\Module-Common.psm1" -ErrorAction Stop
}

function New-EcoTechOUStructure {
    [CmdletBinding(SupportsShouldProcess=$true)]
    param()
    
    Write-EcoLog -Message "Vérification et mise à jour de l'arborescence OU..." -Level Info
    
    try {
        $config = Get-EcoTechConfig
        $domainDN = $config.DomainInfo.DN
        
        $created = 0
        $updated = 0
        $totalOUs = $config.OUStructure.Count
        
        $i = 0
        foreach ($ou in $config.OUStructure) {
            $i++
            # Affichage de la progression en "arrière-plan"
            Write-Progress -Activity "Configuration des OUs" `
                           -Status "Traitement de : $($ou.Name)" `
                           -PercentComplete (($i / $totalOUs) * 100)

            $Path = if ([string]::IsNullOrWhiteSpace($ou.Parent)) { $domainDN } else { "$($ou.Parent),$domainDN" }
            
            # Recherche de l'OU existante (au niveau spécifié uniquement)
            $existing = Get-ADOrganizationalUnit -Filter "Name -eq '$($ou.Name)'" -SearchBase $Path -SearchScope OneLevel -ErrorAction SilentlyContinue

            if ($existing) {
                # L'OU existe : on met à jour la description si elle est différente
                if ($existing.Description -ne $ou.Description) {
                    Set-ADOrganizationalUnit -Identity $existing.DistinguishedName -Description $ou.Description
                    $updated++
                }
            } else {
                # L'OU n'existe pas : on la crée
                if ($PSCmdlet.ShouldProcess("$($ou.Name)", "Créer l'OU")) {
                    New-ADOrganizationalUnit -Name $ou.Name -Path $Path -Description $ou.Description
                    Write-EcoLog -Message "OU Créée : $($ou.Name)" -Level Success
                    $created++
                }
            }
        }
        
        # Bilan final affiché à l'écran
        Write-Host "`n=== BILAN DE L'INFRASTRUCTURE ===" -ForegroundColor Cyan
        Write-Host "  OUs créées      : $created" -ForegroundColor Green
        Write-Host "  OUs mises à jour : $updated" -ForegroundColor Yellow
        Write-Host "  Total traitées  : $totalOUs"
        
    } catch {
        Write-EcoLog -Message "Erreur OU Structure : $($_.Exception.Message)" -Level Error
    }
}

function Remove-EcoTechEntireInfrastructure {
    [CmdletBinding(SupportsShouldProcess=$true)]
    param()
    
    # Confirmation de sécurité
    Write-Host "ATTENTION : Vous allez supprimer toute l'arborescence (EcoTech, UBIHARD, STUDIODLIGHT)." -ForegroundColor Red
    $confirm = Read-Host "Confirmez-vous la suppression ? (OUI pour confirmer)"
    
    if ($confirm -eq "OUI") {
        $racines = @("ECOTECH", "UBIHARD", "STUDIODLIGHT")
        foreach ($name in $racines) {
            $ou = Get-ADOrganizationalUnit -Filter "Name -eq '$name'" -ErrorAction SilentlyContinue
            if ($ou) {
                Write-Host "Suppression de $name..." -ForegroundColor Yellow
                Remove-ADOrganizationalUnit -Identity $ou.DistinguishedName -Recursive -Confirm:$false
                Write-EcoLog -Message "Infrastructure $name supprimée." -Level Warning
            }
        }
    } else {
        Write-Host "Suppression annulée."
    }
}

function Show-OUMenu {
    do {
        Clear-Host
        Write-Host "=== GESTION OU ==="
        Write-Host "1. Initialiser/Mettre à jour toute l'infrastructure "
        Write-Host "2. [DANGER] Supprimer toute l'infrastructure" -ForegroundColor Red
        Write-Host "Q. Retour"
        
        $c = Read-Host "`nChoix"
        
        switch ($c) {
            '1' { New-EcoTechOUStructure; Pause }
            '2' { Remove-EcoTechEntireInfrastructure; Pause }
        }
    } while ($c -ne 'Q')
}

# N'oubliez pas d'exporter la nouvelle fonction de suppression
Export-ModuleMember -Function 'New-EcoTechOUStructure', 'Remove-EcoTechEntireInfrastructure', 'Show-OUMenu'
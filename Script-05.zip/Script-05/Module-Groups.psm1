<#
.SYNOPSIS
    Module de gestion des Groupes.
#>

if (-not (Get-Module Module-Common)) {
    Import-Module "$PSScriptRoot\Module-Common.psm1" -ErrorAction Stop
}

function New-EcoTechSecurityGroups {
    <#
    .DESCRIPTION
        Crée les groupes Globaux (GRP_) dans l'arborescence SX.
    #>
    [CmdletBinding(SupportsShouldProcess=$true)]
    param()
    
    try {
        $config = Get-EcoTechConfig
        $DN = $config.DomainInfo.DN
        
        $groups = @(
            @{Code="D01"; ShortName="RH"}
            @{Code="D02"; ShortName="COMMERCIAL"}
            @{Code="D03"; ShortName="COMMUNICATION"}
            @{Code="D04"; ShortName="DIRECTION"}
            @{Code="D05"; ShortName="DEV"}
            @{Code="D06"; ShortName="FINANCE"}
            @{Code="D07"; ShortName="DSI"}
        )
        
        foreach ($g in $groups) {
            $GroupName = "GRP_$($g.Code)_$($g.ShortName)"
            $Path = "OU=$($g.Code),OU=SX,OU=BDX,OU=ECOTECH,$DN"
            $Desc = "Groupe de sécurité Global - $($g.ShortName)"
            
            # Verifier que l'OU cible existe avant de creer le groupe
            $ouExists = Get-ADOrganizationalUnit -Filter "Name -eq '$($g.Code)'" -SearchBase "OU=SX,OU=BDX,OU=ECOTECH,$DN" -ErrorAction SilentlyContinue
            if (-not $ouExists) {
                Write-EcoLog -Message "OU cible introuvable : $Path (lancez d'abord la creation des OUs)" -Level Warning
                continue
            } 
            
            if (-not (Get-ADGroup -Filter "Name -eq '$GroupName'" -SearchBase $Path -ErrorAction SilentlyContinue)) {
                if ($PSCmdlet.ShouldProcess($GroupName, "Créer Groupe dans SX")) {
                    New-ADGroup -Name $GroupName -GroupScope Global -GroupCategory Security -Path $Path -Description $Desc
                    Write-EcoLog -Message "Groupe créé : $GroupName (dans SX/$($g.Code))" -Level Success
                }
            } else {
                Write-EcoLog -Message "Groupe existe deja : $GroupName" -Level Info
            }
        }
    } catch {
        Write-EcoLog -Message "Erreur Groupes : $($_.Exception.Message)" -Level Error
    }
}

function Add-UsersToGroups {
    <#
    .DESCRIPTION
        Ajoute automatiquement les utilisateurs dans leurs groupes departement.
        Lit les users de chaque OU Dxx et les ajoute au GRP_ correspondant.
    #>
    [CmdletBinding(SupportsShouldProcess=$true)]
    param()
    
    try {
        $config = Get-EcoTechConfig
        $DN = $config.DomainInfo.DN
        
        $deptMap = @{
            "D01" = "GRP_D01_RH"
            "D02" = "GRP_D02_COMMERCIAL"
            "D03" = "GRP_D03_COMMUNICATION"
            "D04" = "GRP_D04_DIRECTION"
            "D05" = "GRP_D05_DEV"
            "D06" = "GRP_D06_FINANCE"
            "D07" = "GRP_D07_DSI"
        }
        
        foreach ($dept in $deptMap.Keys) {
            $GroupName = $deptMap[$dept]
            $SearchBase = "OU=$dept,OU=UX,OU=BDX,OU=ECOTECH,$DN"
            
            # Verifier que l'OU et le groupe existent
            $group = Get-ADGroup -Filter "Name -eq '$GroupName'" -ErrorAction SilentlyContinue
            if (-not $group) { continue }
            
            $ouTest = $null
            try { $ouTest = Get-ADOrganizationalUnit -Identity $SearchBase -ErrorAction SilentlyContinue } catch {}
            if (-not $ouTest) { continue }
            
            # Recuperer tous les users dans cette OU (et sous-OUs)
            $users = Get-ADUser -Filter * -SearchBase $SearchBase -SearchScope Subtree -ErrorAction SilentlyContinue
            
            foreach ($user in $users) {
                try {
                    $isMember = Get-ADGroupMember -Identity $GroupName -ErrorAction SilentlyContinue | Where-Object { $_.SamAccountName -eq $user.SamAccountName }
                    if (-not $isMember) {
                        if ($PSCmdlet.ShouldProcess("$($user.SamAccountName) -> $GroupName", "Ajouter au groupe")) {
                            Add-ADGroupMember -Identity $GroupName -Members $user.SamAccountName
                            Write-EcoLog -Message "Ajout : $($user.SamAccountName) -> $GroupName" -Level Success
                        }
                    }
                } catch {
                    Write-EcoLog -Message "Erreur ajout $($user.SamAccountName) : $($_.Exception.Message)" -Level Error
                }
            }
        }
        
        Write-EcoLog -Message "Association utilisateurs/groupes terminee." -Level Info
        
    } catch {
        Write-EcoLog -Message "Erreur association groupes : $($_.Exception.Message)" -Level Error
    }
}

function Show-GroupMenu {
    Clear-Host
    Write-Host "=== GESTION GROUPES (Zone SX) ==="
    Write-Host "1. Creer les groupes standards"
    Write-Host "2. Associer utilisateurs aux groupes (auto)"
    Write-Host "Q. Retour"
    
    $c = Read-Host "Choix"
    switch ($c) {
        '1' { New-EcoTechSecurityGroups; Pause }
        '2' { Add-UsersToGroups; Pause }
    }
}

Export-ModuleMember -Function 'New-EcoTechSecurityGroups', 'Show-GroupMenu'
<#
.SYNOPSIS
    Gestionnaire Active Directory - EcoTech Solutions

.DESCRIPTION
    Menu principal pour la gestion complète de l'Active Directory :
    - Gestion des OUs (arborescence)
    - Gestion des groupes de sécurité
    - Gestion des utilisateurs (importation CSV, création manuelle)
    - Gestion des ordinateurs (nomenclature ECO-BDX-XX###)

.NOTES
    Auteur: G2 - EcoTech Solutions
#>

[CmdletBinding()]
param()

# -----------------------------------------------------------------------------
# 1. INITIALISATION DE L'ENVIRONNEMENT
# -----------------------------------------------------------------------------

# Forcer la console à utiliser l'UTF-8 pour bien afficher les accents
try { [Console]::OutputEncoding = [System.Text.Encoding]::UTF8 
} catch { 
Write-Host "Info : Impossible de forcer l'UTF-8 (Mode compatible activé)."
}

# Détection robuste du chemin du script (Compatible ISE et Console)
if ($PSScriptRoot) {
    $ScriptRoot = $PSScriptRoot
} elseif ($MyInvocation.MyCommand.Path) {
    $ScriptRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
} else {
    $ScriptRoot = Get-Location
}

Write-Host "Démarrage depuis : $ScriptRoot"

# -----------------------------------------------------------------------------
# 2. CHARGEMENT DES MODULES
# -----------------------------------------------------------------------------

$modules = @(
    "Module-Common.psm1",
    "Module-OU.psm1",
    "Module-Groups.psm1",
    "Module-Users.psm1",
    "Module-Computers.psm1"
)

try {
    foreach ($mod in $modules) {
        $modPath = Join-Path -Path $ScriptRoot -ChildPath $mod
        
        Write-Host "Chargement de $mod..." -NoNewline
        
        if (Test-Path $modPath) {
            # On charge le module. Si ça échoue, on récupère l'erreur.
            try {
                Import-Module $modPath -ErrorAction Stop
                Write-Host " OK"
            } catch {
                Write-Host " ÉCHEC" -ForegroundColor Red
                Write-Host "Erreur dans le module $mod : $($_.Exception.Message)"
                throw $_ 
            }
        } else {
            throw "Fichier introuvable : $modPath"
        }
    }
    Write-Host "Tous les modules sont chargés."
} catch {
    Write-Host "`nERREUR CRITIQUE D'INITIALISATION" -ForegroundColor Red
    Write-Host "Détails : $($_.Exception.Message)" -ForegroundColor Red
    Read-Host "Appuyez sur Entrée pour quitter"
    exit
}

# -----------------------------------------------------------------------------
# 3. INTERFACE UTILISATEUR
# -----------------------------------------------------------------------------

try {
    # On reconstruit le chemin complet vers le fichier de config
    $ConfigPath = Join-Path -Path $ScriptRoot -ChildPath "Config-EcoTechAD.psd1"
    
    # Appel de la fonction du Module-Common
    Import-EcoTechConfig -ConfigPath $ConfigPath | Out-Null
    
    # Init Logs
    Initialize-LogFile -LogPath "$ScriptRoot\Logs\EcoTech.log"
} catch {
    Write-Host "Erreur Configuration : $($_.Exception.Message)" -ForegroundColor Red
    Read-Host "Appuyez sur Entrée pour quitter"
    exit
}

# 4. Menu Principal
function Show-MainMenu {
    Clear-Host
    Write-Host "========================================================"
    Write-Host "             ECOTECH SOLUTIONS - MANAGER AD             "
    Write-Host "========================================================"
    
    # On vérifie que la fonction existe avant de l'appeler
    if (Get-Command Show-EcoTechStatus -ErrorAction SilentlyContinue) {
        Show-EcoTechStatus
    }
    
	Write-Host "MENU PRINCIPAL :" 
	Write-Host "1. Gestion OUs (Architecture)"
    Write-Host "2. Gestion Groupes (SX)"
    Write-Host "3. Gestion Utilisateurs (UX)"
    Write-Host "4. Gestion Ordinateurs (WX)"
    Write-Host "  Q. Quitter" 
    Write-Host ""
    
    $choice = Read-Host "Votre choix"
    
    switch ($choice) {
        '1' { Show-OUMenu }
        '2' { Show-GroupMenu }
        '3' { Show-UserMenu }
        '4' { Show-ComputerMenu }
        'Q' { return 'Q' }
        Default { Write-Host "Choix invalide." -ForegroundColor Red; Start-Sleep -Seconds 1 }
    }
}

# -----------------------------------------------------------------------------
# 4. EXÉCUTION
# -----------------------------------------------------------------------------

# Boucle principale
do {
    $action = Show-MainMenu
} while ($action -ne 'Q')

Write-Host "Au revoir !"
Start-Sleep -Seconds 1
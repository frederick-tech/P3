
```PowerShell
<#
.SYNOPSIS
    Gestionnaire Active Directory - EcoTech Solutions

.DESCRIPTION
    Menu principal pour la gestion complète de l'Active Directory :
    - Gestion des OUs (arborescence)
    - Gestion des groupes de sécurité
    - Gestion des utilisateurs (importation CSV, création manuelle)
    - Gestion des ordinateurs (nomenclature ECO-BDX-XX###)

.NOTES
    Auteur: G2 - EcoTech Solutions
    
.EXAMPLE
    .\Start-ADManager.ps1
#>

[CmdletBinding()]
param()

# -----------------------------------------------------------------------------
# 1. INITIALISATION DE L'ENVIRONNEMENT
# -----------------------------------------------------------------------------

# Forcer la console à utiliser l'UTF-8 pour bien afficher les accents
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8

# Détection robuste du chemin du script (Compatible ISE et Console)
if ($PSScriptRoot) {
    $ScriptRoot = $PSScriptRoot
} elseif ($MyInvocation.MyCommand.Path) {
    $ScriptRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
} else {
    $ScriptRoot = Get-Location
}

Write-Host "Démarrage depuis : $ScriptRoot"

# -----------------------------------------------------------------------------
# 2. CHARGEMENT DES MODULES
# -----------------------------------------------------------------------------

$modules = @(
    "Module-Common.psm1",
    "Module-OU.psm1",
    "Module-Groups.psm1",
    "Module-Users.psm1",
    "Module-Computers.psm1"
)

try {
    foreach ($mod in $modules) {
        $modPath = Join-Path -Path $ScriptRoot -ChildPath $mod
        if (Test-Path $modPath) {
            # On utilise -Force pour recharger si nécessaire, et -ErrorAction Stop pour bloquer en cas d'erreur
            Import-Module $modPath -Force -ErrorAction Stop
        } else {
            throw "Le module '$mod' est introuvable dans le dossier."
        }
    }
    Write-Host "Modules chargés avec succès."
} catch {
    Write-Host "ERREUR CRITIQUE : Impossible de charger les modules." -ForegroundColor Red
    Write-Host "Détail : $($_.Exception.Message)" -ForegroundColor Red
    Write-Host "Vérifiez que tous les fichiers .psm1 sont bien dans : $ScriptRoot"
    Read-Host "Appuyez sur Entrée pour quitter"
    exit 1
}

# -----------------------------------------------------------------------------
# 3. INTERFACE UTILISATEUR
# -----------------------------------------------------------------------------

function Initialize-ADManager {
    # Tente de charger la config dès le démarrage
    try {
        $config = Import-EcoTechConfig -ConfigPath (Join-Path $ScriptRoot "Config-EcoTechAD.psd1")
        
        # Initialiser le fichier de log
        Initialize-LogFile -LogPath "$ScriptRoot\Logs\EcoTechAD.log"
        return $true
    } catch {
        Write-Host "Erreur d'initialisation : $($_.Exception.Message)" -ForegroundColor Red
        return $false
    }
}

function Show-MainMenu {
    Clear-Host
    Write-Host "========================================================"
    Write-Host "      ECOTECH SOLUTIONS - GESTION ACTIVE DIRECTORY      "
    Write-Host "========================================================"
    Write-Host ""
    
    Show-EcoTechStatus # Affiche l'état (Domaine, Utilisateur connecté...)
    
    Write-Host "MENU PRINCIPAL :" 
    Write-Host "  1. Gestion des OUs (Architecture)" 
    Write-Host "  2. Gestion des Groupes de Sécurité" 
    Write-Host "  3. Gestion des Utilisateurs" 
    Write-Host "  4. Gestion des Ordinateurs" 
    Write-Host "  Q. Quitter" 
    Write-Host ""
    
    $choice = Read-Host "Votre choix"
    
    switch ($choice) {
        '1' { Show-OUMenu }
        '2' { Show-GroupMenu }
        '3' { Show-UserMenu }
        '4' { Show-ComputerMenu }
        'Q' { return 'Q' }
        Default { Write-Host "Choix invalide." -ForegroundColor Red; Start-Sleep -Seconds 1 }
    }
}

# -----------------------------------------------------------------------------
# 4. EXÉCUTION
# -----------------------------------------------------------------------------

# Initialiser
if (-not (Initialize-ADManager)) {
    Write-Host "Échec de l'initialisation. Le script va s'arrêter." -ForegroundColor Red
    Read-Host "Appuyez sur Entrée pour quitter"
    exit
}

# Boucle principale
do {
    $action = Show-MainMenu
} while ($action -ne 'Q')

Write-Host "Au revoir !"
Start-Sleep -Seconds 1
```

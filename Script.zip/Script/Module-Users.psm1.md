
```PowerShell
<#
.SYNOPSIS
    Module de gestion des utilisateurs pour EcoTech Solutions (Multi-Sociétés & Services)

.DESCRIPTION
    Gère le cycle de vie des utilisateurs :
    - Importation CSV intelligente (mapping Départements -> OU)
    - Gestion dynamique des attributs
    - Création unitaire
    - Génération automatique des logins
    
.NOTES
    Auteur: Équipe Admin SI
    Version: 2.2 (Support Attributs Dynamiques)
#>

if (-not (Get-Module Module-Common)) {
    Import-Module "$PSScriptRoot\Module-Common.psm1" -ErrorAction Stop
}

function Import-EcoTechUsers {
    [CmdletBinding(SupportsShouldProcess=$true)]
    param(
        [Parameter(Mandatory=$true)]
        [ValidateScript({Test-Path $_ -PathType Leaf})]
        [string]$CSVPath,
        [switch]$UpdateExisting
    )
    
    try {
        $config = Get-EcoTechConfig
        $defaultPassword = ConvertTo-SecureString $config.DefaultPassword -AsPlainText -Force
        $users = Import-Csv -Path $CSVPath -Delimiter ";" -Encoding UTF8
        $dn = $config.DomainInfo.DN 
        
        foreach ($row in $users) {
            $SamAccountName = Get-CalculatedLogin -Prenom $row.Prenom -Nom $row.Nom
            
            # 1. Détermination de la Racine (Société)
            # UBIHard -> UBIHARD / Studio Dlight -> STUDIODLIGHT / Autres -> ECOTECH
            $RootOU = switch -Wildcard ($row.Societe) {
                "*UBIHard*"        { "UBIHARD" }
                "*Studio Dlight*"  { "STUDIODLIGHT" }
                Default            { "ECOTECH" }
            }

            # 2. Détermination du Site (Localisation)
            $SiteOU = switch -Wildcard ($row.Site) {
                "*Paris*"    { "PAR" }
                "*Nantes*"   { "NTE" }
                Default      { "BDX" }
            }
            
            # 3. Récupération Dept & Service
            $NomDept    = $row.Departement
            $NomService = $row.Service
            
            $CodeDept    = $config.DepartmentMapping[$NomDept]
            $CodeService = $config.ServiceMapping[$NomService]

            if ($CodeDept) {
                # Base du chemin : OU=UX,OU=[SITE],OU=[SOCIETE]
                $BaseUserPath = "OU=UX,OU=$SiteOU,OU=$RootOU,$dn"
                
                # --- LOGIQUE DE PLACEMENT ---
                if ($RootOU -eq "ECOTECH") {
                    # Chez EcoTech, on a la granularité Services (Sxx sous Dxx)
                    if ($CodeService) {
                        $TargetOU = "OU=$CodeService,OU=$CodeDept,$BaseUserPath"
                    } else {
                        $TargetOU = "OU=$CodeDept,$BaseUserPath"
                        if (-not [string]::IsNullOrWhiteSpace($NomService)) {
                            Write-EcoLog -Message "Service '$NomService' inconnu chez EcoTech. Utilisateur placé dans $CodeDept racine." -Level Warning
                        }
                    }
                } else {
                    # Chez les partenaires (UBIHard/Studio), on a juste Dxx sous UX (pas de services Sxx définis dans OU.md)
                    # On place donc directement dans le département.
                    $TargetOU = "OU=$CodeDept,$BaseUserPath"
                }
                
                # Attributs dynamiques
                $Societe = if ($row.Societe) { $row.Societe } else { "EcoTechSolutions" }
                $Site    = if ($row.Site)    { $row.Site }    else { "Bordeaux" }

                # Création
                if ($PSCmdlet.ShouldProcess("$SamAccountName", "Créer User dans $RootOU/$SiteOU")) {
                    try {
                        if (-not (Get-ADUser -Filter "SamAccountName -eq '$SamAccountName'" -ErrorAction SilentlyContinue)) {
                            New-ADUser -Name "$($row.Prenom) $($row.Nom)" `
                                -SamAccountName $SamAccountName `
                                -GivenName $row.Prenom `
                                -Surname $row.Nom `
                                -DisplayName "$($row.Prenom) $($row.Nom)" `
                                -UserPrincipalName "$SamAccountName@$($config.DomainInfo.EmailDomain)" `
                                -Path $TargetOU `
                                -AccountPassword $defaultPassword `
                                -Enabled $true `
                                -ChangePasswordAtLogon $true `
                                -Department $NomDept `
                                -Company $Societe `
                                -Office $Site `
                                -Title $row.Fonction `
                                -Description "$NomService"
                            
                            Write-EcoLog -Message "OK : $SamAccountName ($RootOU - $CodeDept)" -Level Success
                        } else {
                            if ($UpdateExisting) {
                                Set-ADUser -Identity $SamAccountName -Company $Societe -Office $Site -Department $NomDept
                                Write-EcoLog -Message "MàJ : $SamAccountName" -Level Info
                            }
                        }
                    } catch {
                        Write-EcoLog -Message "Erreur $SamAccountName : $($_.Exception.Message)" -Level Error
                        Write-EcoLog -Message "Cible : $TargetOU" -Level Info
                    }
                }
            } else {
                Write-EcoLog -Message "Dept inconnu '$NomDept' pour $SamAccountName" -Level Error
            }
        }
    } catch {
        Write-EcoLog -Message "Erreur CSV : $($_.Exception.Message)" -Level Error
    }
}

function New-EcoTechUser {
    # Version manuelle simplifiée
    param($Prenom, $Nom, $Departement, $Service, $Societe="EcoTechSolutions", $Site="Bordeaux")
    
    $config = Get-EcoTechConfig
    $dn = $config.DomainInfo.DN
    $SamAccountName = Get-CalculatedLogin -Prenom $Prenom -Nom $Nom
    
    $RootOU = if ($Societe -match "UBIHard") { "UBIHARD" } elseif ($Societe -match "Studio") { "STUDIODLIGHT" } else { "ECOTECH" }
    $SiteOU = if ($Site -match "Paris") { "PAR" } elseif ($Site -match "Nantes") { "NTE" } else { "BDX" }
    
    $CodeDept = $config.DepartmentMapping[$Departement]
    
    if ($CodeDept) {
        $BaseUserPath = "OU=UX,OU=$SiteOU,OU=$RootOU,$dn"
        $TargetOU = "OU=$CodeDept,$BaseUserPath"
        
        # Si EcoTech et Service connu, on descend d'un cran
        if ($RootOU -eq "ECOTECH") {
            $CodeService = $config.ServiceMapping[$Service]
            if ($CodeService) { $TargetOU = "OU=$CodeService,$TargetOU" }
        }
        
        $pwd = ConvertTo-SecureString $config.DefaultPassword -AsPlainText -Force
        try {
            New-ADUser -Name "$Prenom $Nom" -SamAccountName $SamAccountName -Path $TargetOU -AccountPassword $pwd -Enabled $true `
                -Company $Societe -Office $Site -Department $Departement
            Write-Host "Créé : $SamAccountName" -ForegroundColor Green
        } catch {
            Write-Host "Erreur : $($_.Exception.Message)" -ForegroundColor Red
        }
    }
}

function Show-UserMenu {
    Clear-Host
    Write-Host "=== GESTION USERS ==="
    Write-Host "1. Import CSV"
    Write-Host "2. Manuel"
    Write-Host "Q. Retour"
    $c = Read-Host "Choix"
    if ($c -eq '1') { 
        $p = Read-Host "Chemin CSV"
        Import-EcoTechUsers -CSVPath $p
        Pause
    }
    if ($c -eq '2') {
        $p = Read-Host "Prénom"; $n = Read-Host "Nom"; 
        $d = Read-Host "Département"; $soc = Read-Host "Société"; $sit = Read-Host "Site"
        $s = Read-Host "Service"
        New-EcoTechUser -Prenom $p -Nom $n -Departement $d -Societe $soc -Site $sit -Service $s
        Pause
    }
}

Export-ModuleMember -Function 'Import-EcoTechUsers', 'New-EcoTechUser', 'Show-UserMenu'
```

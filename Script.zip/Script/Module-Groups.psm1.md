
```PowerShell
<#
.SYNOPSIS
    Module de gestion des Groupes.
#>

if (-not (Get-Module Module-Common)) {
    Import-Module "$PSScriptRoot\Module-Common.psm1" -ErrorAction Stop
}

function New-EcoTechSecurityGroups {
    <#
    .DESCRIPTION
        Crée les groupes Globaux (GRP_) dans l'arborescence SX.
    #>
    [CmdletBinding(SupportsShouldProcess=$true)]
    param()
    
    try {
        $config = Get-EcoTechConfig
        $DN = $config.DomainInfo.DN
        
        $groups = @(
            @{Code="D01"; ShortName="RH"}
            @{Code="D02"; ShortName="COMMERCIAL"}
            @{Code="D03"; ShortName="COMMUNICATION"}
            @{Code="D04"; ShortName="DIRECTION"}
            @{Code="D05"; ShortName="DEV"}
            @{Code="D06"; ShortName="FINANCE"}
            @{Code="D07"; ShortName="DSI"}
        )
        
        foreach ($g in $groups) {
            $GroupName = "GRP_$($g.Code)_$($g.ShortName)"
            
            # CIBLE : OU=Dxx,OU=SX,OU=BDX... (Validation du SX)
            $Path = "OU=$($g.Code),OU=SX,OU=BDX,OU=ECOTECH,$DN"
            
            $Desc = "Groupe de sécurité Global - $($g.ShortName)"
            
            if (-not (Get-ADGroup -Filter "Name -eq '$GroupName'" -SearchBase $Path -ErrorAction SilentlyContinue)) {
                if ($PSCmdlet.ShouldProcess($GroupName, "Créer Groupe dans SX")) {
                    New-ADGroup -Name $GroupName -GroupScope Global -GroupCategory Security -Path $Path -Description $Desc
                    Write-EcoLog -Message "Groupe créé : $GroupName (dans SX/$($g.Code))" -Level Success
                }
            }
        }
    } catch {
        Write-EcoLog -Message "Erreur Groupes : $($_.Exception.Message)" -Level Error
    }
}

function Show-GroupMenu {
    Clear-Host
    Write-Host "=== GESTION GROUPES (Zone SX) ==="
    Write-Host "1. Créer les groupes standards"
    Write-Host "Q. Retour"
    if ((Read-Host "Choix") -eq '1') { New-EcoTechSecurityGroups; Pause }
}

Export-ModuleMember -Function 'New-EcoTechSecurityGroups', 'Show-GroupMenu'
```

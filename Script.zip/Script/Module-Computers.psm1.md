
```PowerShell
<#
.SYNOPSIS
    Module de gestion des Ordinateurs.
#>

if (-not (Get-Module Module-Common)) {
    Import-Module "$PSScriptRoot\Module-Common.psm1" -ErrorAction Stop
}

function Import-EcoTechComputers {
    param([string]$CSVPath)
    
    $config = Get-EcoTechConfig
    $users = Import-Csv $CSVPath -Delimiter ";" -Encoding UTF8
    
    foreach ($row in $users) {
        # On peut récupérer le nom du PC depuis le CSV (PAxxxxx)
        # Ou générer un nom séquentiel ECO-BDX... 
        # Ici, je prends le nom du CSV pour coller à ton fichier :
        $ComputerName = $row.'Nom de PC'
        
        # Détermination du type (Portable CX ou Fixe BX ?)
        # Par défaut, on met tout dans CX (Portable) si on ne sait pas, 
        # ou on peut se baser sur une logique. Disons CX par défaut.
        $TargetOU = "OU=CX,OU=WX,OU=BDX,OU=ECOTECH,$($config.DomainInfo.DN)"
        
        try {
            if (-not (Get-ADComputer -Identity $ComputerName -ErrorAction SilentlyContinue)) {
                New-ADComputer -Name $ComputerName -Path $TargetOU -Description "PC de $($row.Prenom) $($row.Nom)"
                Write-EcoLog -Message "PC Créé : $ComputerName" -Level Success
            }
        } catch {
            Write-EcoLog -Message "Erreur PC $ComputerName : $($_.Exception.Message)" -Level Error
        }
    }
}

function Show-ComputerMenu {
    Clear-Host
    Write-Host "=== GESTION ORDI ==="
    Write-Host "1. Import CSV (Création des objets ordis)"
    Write-Host "Q. Retour"
    $c = Read-Host "Choix"
    if ($c -eq '1') { 
        $p = Read-Host "Chemin CSV"
        Import-EcoTechComputers -CSVPath $p
        Pause 
    }
}

Export-ModuleMember -Function 'Import-EcoTechComputers', 'Show-ComputerMenu'
```

<#
.SYNOPSIS
    Module de fonctions communes pour la gestion Active Directory d'EcoTech Solutions

.DESCRIPTION
    Ce module contient les fonctions utilitaires partagées par tous les autres modules :
    - Logging
    - Normalisation de chaînes
    - Chargement de la configuration
    - Génération de noms

.NOTES
    Auteur: G2 - EcoTech Solutions
#>

#region Variables globales du module
$Script:Config = $null
$Script:LogFile = $null
#endregion

#region Fonctions de configuration

function Import-EcoTechConfig {
    <#
    .DESCRIPTION
        Importe le fichier de configuration central et le stocke en variable de script
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$false)]
        [string]$ConfigPath = "$PSScriptRoot\Config-EcoTechAD.psd1"
    )
    
    try {
        if (-not (Test-Path $ConfigPath)) {
            throw "Fichier de configuration introuvable : $ConfigPath"
        }
        
        $Script:Config = Import-PowerShellDataFile -Path $ConfigPath
        Write-Host "Configuration chargée depuis : $ConfigPath" -ForegroundColor Green
        return $Script:Config
        
    } catch {
        Write-Host "Erreur lors du chargement de la configuration : $($_.Exception.Message)" -ForegroundColor Red
        throw
    }
}

function Get-EcoTechConfig {
    <#
    .DESCRIPTION
        Retourne l'objet de configuration chargé en mémoire
    #>
    [CmdletBinding()]
    param()
    
    if ($null -eq $Script:Config) {
        throw "Configuration non chargée. Utilisez Import-EcoTechConfig d'abord."
    }
    
    return $Script:Config
}

#endregion

#region Fonctions de logging

function Initialize-LogFile {
    <#
    .SYNOPSIS
        Initialise le fichier de log
    
    .DESCRIPTION
        Crée le répertoire de logs si nécessaire et définit le chemin du fichier
    
    .PARAMETER LogPath
        Chemin du répertoire de logs
    
    .EXAMPLE
        Initialize-LogFile -LogPath "C:\Logs\EcoTech-AD"
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$false)]
        [string]$LogPath
    )
    
    if (-not $LogPath) {
        $config = Get-EcoTechConfig
        $LogPath = $config.LogPath
    }
    
    # Créer le répertoire si nécessaire
    if (-not (Test-Path $LogPath)) {
        New-Item -Path $LogPath -ItemType Directory -Force | Out-Null
    }
    
    # Définir le nom du fichier avec timestamp
    $timestamp = Get-Date -Format "yyyyMMdd-HHmmss"
    $Script:LogFile = Join-Path $LogPath "ADManager-$timestamp.log"
    
    Write-Host "📝 Logs : $Script:LogFile" -ForegroundColor Cyan
}

function Write-EcoLog {
    <#
    .DESCRIPTION
        Écrit un message horodaté dans le log avec niveau de gravité

    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)]
        [string]$Message,
        
        [Parameter(Mandatory=$false)]
        [ValidateSet('Info','Success','Warning','Error')]
        [string]$Level = 'Info'
    )
    
    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $logMessage = "[$timestamp] [$Level] $Message"
    
    # Écrire dans le fichier si initialisé
    if ($Script:LogFile) {
        Add-Content -Path $Script:LogFile -Value $logMessage
    }
    
    # Afficher à l'écran avec couleur
    $color = switch ($Level) {
        'Success' { 'Green' }
        'Warning' { 'Yellow' }
        'Error'   { 'Red' }
        default   { 'White' }
    }
    
    Write-Host $logMessage -ForegroundColor $color
}

#endregion

#region Fonctions de normalisation

function Get-NormalizedString {
    <#
    .DESCRIPTION
        Supprime les accents, caractères spéciaux et convertit en minuscules
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)]
        [string]$InputString
    )
    
    # Supprimer les accents
    $normalized = $InputString.Normalize([Text.NormalizationForm]::FormD)
    $sb = New-Object Text.StringBuilder
    
    foreach ($char in $normalized.ToCharArray()) {
        $category = [Globalization.CharUnicodeInfo]::GetUnicodeCategory($char)
        if ($category -ne [Globalization.UnicodeCategory]::NonSpacingMark) {
            [void]$sb.Append($char)
        }
    }
    
    # Supprimer caractères spéciaux et espaces
    $result = $sb.ToString()
    $result = $result -replace '[^a-zA-Z0-9]', ''
    
    return $result.ToLower()
}

#endregion

#region Fonctions de génération de noms

function New-SamAccountName {
    <#
    .DESCRIPTION
        Crée un nom d'utilisateur au format prenom.nom avec gestion des doublons
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)]
        [string]$Prenom,
        
        [Parameter(Mandatory=$true)]
        [string]$Nom
    )
    
    $prenomClean = Get-NormalizedString -InputString $Prenom
    $nomClean = Get-NormalizedString -InputString $Nom
    
    $samBase = "$prenomClean.$nomClean"
    $samAccount = $samBase
    $counter = 2
    
    # Vérifier l'unicité
    while (Get-ADUser -Filter "SamAccountName -eq '$samAccount'" -ErrorAction SilentlyContinue) {
        $samAccount = "$samBase$counter"
        $counter++
    }
    
    return $samAccount
}

function New-EmailAddress {
    <#
    .DESCRIPTION
        Crée une adresse au format <2lettres><nom>@ecotechsolutions.fr
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)]
        [string]$Prenom,
        
        [Parameter(Mandatory=$true)]
        [string]$Nom
    )
    
    $config = Get-EcoTechConfig
    
    $prenomClean = Get-NormalizedString -InputString $Prenom
    $nomClean = Get-NormalizedString -InputString $Nom
    
    # Prendre les 2 premières lettres du prénom
    $prenomPrefix = $prenomClean.Substring(0, [Math]::Min(2, $prenomClean.Length))
    
    return "$prenomPrefix$nomClean@$($config.DomainInfo.EmailDomain)"
}

function New-ComputerName {
    <#
    .DESCRIPTION
        Crée un nom au format ECO-BDX-TYPE### (ex: ECO-BDX-CX001)
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)]
        [ValidateSet('BX','CX','EX','FX','GX')]
        [string]$Type,
        
        [Parameter(Mandatory=$false)]
        [int]$NextNumber
    )
    
    # Si le numéro n'est pas fourni, trouver le prochain disponible
    if (-not $NextNumber) {
        $prefix = "ECO-BDX-$Type"
        $existing = Get-ADComputer -Filter "Name -like '$prefix*'" -ErrorAction SilentlyContinue
        
        if ($existing) {
            # Extraire les numéros et trouver le maximum
            $numbers = $existing | ForEach-Object {
                if ($_.Name -match "$prefix(\d+)$") {
                    [int]$matches[1]
                }
            }
            $NextNumber = ($numbers | Measure-Object -Maximum).Maximum + 1
        } else {
            $NextNumber = 1
        }
    }
    
    # Formater avec 3 chiffres
    return "ECO-BDX-{0}{1:D3}" -f $Type, $NextNumber
}

#endregion

#region Fonctions de navigation AD

function Get-OUPath {
    <#
    .DESCRIPTION
        Génère le Distinguished Name complet pour une OU
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)]
        [string]$OUPath
    )
    
    $config = Get-EcoTechConfig
    
    if ($OUPath) {
        return "$OUPath,$($config.DomainInfo.DN)"
    } else {
        return $config.DomainInfo.DN
    }
}

#endregion

#region Fonctions d'affichage

function Show-Banner {
    <#
    .DESCRIPTION
        Affiche une bannière stylisée pour l'application
    #>
    [CmdletBinding()]
    param()
    
    Clear-Host
    Write-Host ""
    Write-Host "┌────────────────────────────────────────────────────────┐" 
    Write-Host "│   GESTIONNAIRE ACTIVE DIRECTORY - ECOTECH SOLUTIONS    │" 
    Write-Host "└────────────────────────────────────────────────────────┘" 
    Write-Host ""
}

function Show-StatusBar {
    <#
    .SYNOPSIS
    .DESCRIPTION
        Affiche les informations de connexion au domaine
    #>
    [CmdletBinding()]
    param()
    
    try {
        $domain = Get-ADDomain -ErrorAction Stop
        $config = Get-EcoTechConfig
        
        Write-Host "┌────────────────────────────────────────────────────────┐" 
        Write-Host "│ Domaine : " -NoNewline 
        Write-Host "$($domain.DNSRoot)" -NoNewline 
        Write-Host (" " * (41 - $domain.DNSRoot.Length)) -NoNewline
        Write-Host "│" 
        
        Write-Host "│ Utilisateur : " -NoNewline 
        Write-Host "$env:USERNAME" -NoNewline
        Write-Host (" " * (37 - $env:USERNAME.Length)) -NoNewline
        Write-Host "│" 
        
        Write-Host "└────────────────────────────────────────────────────────┘" 
        Write-Host ""
        
    } catch {
        Write-Host "Non connecté au domaine" -ForegroundColor Red
        Write-Host ""
    }
}

function Read-Choice {
    <#
    .DESCRIPTION
        Affiche un prompt et attend la saisie utilisateur
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)]
        [string]$Prompt,
        
        [Parameter(Mandatory=$false)]
        [string[]]$ValidChoices
    )
    
    do {
        Write-Host ""
        Write-Host $Prompt -NoNewline 
        Write-Host " : " -NoNewline
        $choice = Read-Host
        
        if ($ValidChoices -and $choice -notin $ValidChoices) {
            Write-Host "Choix invalide. Veuillez réessayer." -ForegroundColor Red
        }
    } while ($ValidChoices -and $choice -notin $ValidChoices)
    
    return $choice
}

#endregion

# Exporter les fonctions
Export-ModuleMember -Function @(
    'Import-EcoTechConfig',
    'Get-EcoTechConfig',
    'Initialize-LogFile',
    'Write-EcoLog',
    'Get-NormalizedString',
    'New-SamAccountName',
    'New-EmailAddress',
    'New-ComputerName',
    'Get-OUPath',
    'Show-Banner',
    'Show-StatusBar',
    'Read-Choice'
)


```PowerShell
<#
.SYNOPSIS
    Module de gestion des utilisateurs pour EcoTech Solutions (Multi-Societes & Services)

.DESCRIPTION
    Gere le cycle de vie des utilisateurs :
    - Importation CSV intelligente (mapping Departements -> OU)
    - Gestion dynamique des attributs
    - Creation unitaire
    - Generation automatique des logins
    - Verification de synchronisation CSV <-> AD

.NOTES
    Auteur: Equipe Admin SI
    Version: 2.3 (+ Sync Check)
#>

if (-not (Get-Module Module-Common)) {
    Import-Module "$PSScriptRoot\Module-Common.psm1" -ErrorAction Stop
}

function Import-EcoTechUsers {
    [CmdletBinding(SupportsShouldProcess=$true)]
    param(
        [Parameter(Mandatory=$true)]
        [ValidateScript({Test-Path $_ -PathType Leaf})]
        [string]$CSVPath,
        [switch]$UpdateExisting
    )
    
    try {
        $config = Get-EcoTechConfig
        $defaultPassword = ConvertTo-SecureString $config.DefaultPassword -AsPlainText -Force
        $users = Import-Csv -Path $CSVPath -Delimiter ";" -Encoding UTF8
        $dn = $config.DomainInfo.DN
        
        $created = 0
        $updated = 0
        $errors  = 0
        
        foreach ($row in $users) {
            $SamAccountName = Get-CalculatedLogin -Prenom $row.Prenom -Nom $row.Nom
            
            # 1. Determination de la Racine (Societe)
            $RootOU = switch -Wildcard ($row.Societe) {
                "*UBIHard*"        { "UBIHARD" }
                "*Studio Dlight*"  { "STUDIODLIGHT" }
                Default            { "ECOTECH" }
            }

            # 2. Determination du Site (Localisation)
            $SiteOU = switch -Wildcard ($row.Site) {
                "*Paris*"    { "PAR" }
                "*Nantes*"   { "NTE" }
                Default      { "BDX" }
            }
            
            # 3. Recuperation Dept & Service
            $NomDept    = $row.Departement
            $NomService = $row.Service
            
            $CodeDept    = $config.DepartmentMapping[$NomDept]
            $CodeService = $config.ServiceMapping[$NomService]

            if ($CodeDept) {
                $BaseUserPath = "OU=UX,OU=$SiteOU,OU=$RootOU,$dn"
                
                if ($RootOU -eq "ECOTECH") {
                    if ($CodeService) {
                        $TargetOU = "OU=$CodeService,OU=$CodeDept,$BaseUserPath"
                    } else {
                        $TargetOU = "OU=$CodeDept,$BaseUserPath"
                        if (-not [string]::IsNullOrWhiteSpace($NomService)) {
                            Write-EcoLog -Message "Service '$NomService' inconnu. User place dans $CodeDept." -Level Warning
                        }
                    }
                } else {
                    $TargetOU = "OU=$CodeDept,$BaseUserPath"
                }
                
                $Societe = if ($row.Societe) { $row.Societe } else { "EcoTechSolutions" }
                $Site    = if ($row.Site)    { $row.Site }    else { "Bordeaux" }

                if ($PSCmdlet.ShouldProcess("$SamAccountName", "Creer User dans $RootOU/$SiteOU")) {
                    try {
                        $existingUser = Get-ADUser -Filter "SamAccountName -eq '$SamAccountName'" -ErrorAction SilentlyContinue
                        
                        if (-not $existingUser) {
                            New-ADUser -Name "$($row.Prenom) $($row.Nom)" `
                                -SamAccountName $SamAccountName `
                                -GivenName $row.Prenom `
                                -Surname $row.Nom `
                                -DisplayName "$($row.Prenom) $($row.Nom)" `
                                -UserPrincipalName "$SamAccountName@$($config.DomainInfo.EmailDomain)" `
                                -Path $TargetOU `
                                -AccountPassword $defaultPassword `
                                -Enabled $true `
                                -ChangePasswordAtLogon $true `
                                -Department $NomDept `
                                -Company $Societe `
                                -Office $Site `
                                -Title $row.Fonction `
                                -Description "$NomService"
                            
                            Write-EcoLog -Message "OK : $SamAccountName ($RootOU - $CodeDept)" -Level Success
                            $created++
                        } else {
                            if ($UpdateExisting) {
                                Set-ADUser -Identity $SamAccountName `
                                    -Company $Societe `
                                    -Office $Site `
                                    -Department $NomDept `
                                    -Title $row.Fonction `
                                    -Description "$NomService"
                                Write-EcoLog -Message "MAJ : $SamAccountName" -Level Info
                                $updated++
                            } else {
                                Write-EcoLog -Message "Existe deja : $SamAccountName (utiliser -UpdateExisting pour MAJ)" -Level Warning
                            }
                        }
                    } catch {
                        Write-EcoLog -Message "Erreur $SamAccountName : $($_.Exception.Message)" -Level Error
                        Write-EcoLog -Message "  Cible : $TargetOU" -Level Info
                        $errors++
                    }
                }
            } else {
                Write-EcoLog -Message "Dept inconnu '$NomDept' pour $($row.Prenom) $($row.Nom)" -Level Error
                $errors++
            }
        }
        
        Write-Host ""
        Write-EcoLog -Message "=== BILAN : $created crees | $updated MAJ | $errors erreurs ===" -Level Info
        
    } catch {
        Write-EcoLog -Message "Erreur CSV : $($_.Exception.Message)" -Level Error
    }
}

function Compare-EcoTechSync {
    <#
    .SYNOPSIS
        Verifie la synchronisation entre un fichier CSV et l'Active Directory.
    
    .DESCRIPTION
        Compare chaque ligne du CSV avec l'AD et detecte :
        - Utilisateurs CSV absents de l'AD
        - Utilisateurs AD absents du CSV (orphelins)
        - Attributs qui ne correspondent pas (Departement, Societe, Site, Fonction, OU)
        Genere un rapport console + export CSV optionnel.
    
    .PARAMETER CSVPath
        Chemin vers le fichier CSV source.
    
    .PARAMETER ExportReport
        Si present, exporte le rapport dans un fichier CSV.
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)]
        [ValidateScript({Test-Path $_ -PathType Leaf})]
        [string]$CSVPath,
        
        [switch]$ExportReport
    )
    
    try {
        $config = Get-EcoTechConfig
        $dn = $config.DomainInfo.DN
        $csvUsers = Import-Csv -Path $CSVPath -Delimiter ";" -Encoding UTF8
        
        # Compteurs
        $total     = 0
        $ok        = 0
        $missing   = 0
        $mismatch  = 0
        $orphans   = 0
        
        # Tableau de resultats pour le rapport
        $report = @()
        
        # Liste des logins CSV pour detecter les orphelins
        $csvLogins = @()
        
        Write-Host ""
        Write-Host "============================================="
        Write-Host "       VERIFICATION SYNCHRO CSV <-> AD       " 
        Write-Host "=============================================" 
        Write-Host "Source  : $CSVPath"
        Write-Host "Domaine : $($config.DomainInfo.Name)"
        Write-Host ""
        
        # =============================================
        # PASSE 1 : Chaque user du CSV -> existe dans l'AD ?
        # =============================================
        
        foreach ($row in $csvUsers) {
            $total++
            $SamAccountName = Get-CalculatedLogin -Prenom $row.Prenom -Nom $row.Nom
            $csvLogins += $SamAccountName
            
            # Calcul de l'OU attendue (meme logique que Import)
            $RootOU = switch -Wildcard ($row.Societe) {
                "*UBIHard*"        { "UBIHARD" }
                "*Studio Dlight*"  { "STUDIODLIGHT" }
                Default            { "ECOTECH" }
            }
            $SiteOU = switch -Wildcard ($row.Site) {
                "*Paris*"    { "PAR" }
                "*Nantes*"   { "NTE" }
                Default      { "BDX" }
            }
            
            $CodeDept    = $config.DepartmentMapping[$row.Departement]
            $CodeService = $config.ServiceMapping[$row.Service]
            
            if ($CodeDept) {
                $BaseUserPath = "OU=UX,OU=$SiteOU,OU=$RootOU,$dn"
                if ($RootOU -eq "ECOTECH" -and $CodeService) {
                    $ExpectedOU = "OU=$CodeService,OU=$CodeDept,$BaseUserPath"
                } else {
                    $ExpectedOU = "OU=$CodeDept,$BaseUserPath"
                }
            } else {
                $ExpectedOU = "INCONNU (Dept '$($row.Departement)' non mappe)"
            }
            
            # Chercher le user dans l'AD
            $adUser = Get-ADUser -Filter "SamAccountName -eq '$SamAccountName'" `
                        -Properties Department, Company, Office, Title, Description, DistinguishedName `
                        -ErrorAction SilentlyContinue
            
            if (-not $adUser) {
                # --- USER ABSENT DE L'AD ---
                $missing++
                Write-Host "  [ABSENT]   $SamAccountName ($($row.Prenom) $($row.Nom))" -ForegroundColor Red
                
                $report += [PSCustomObject]@{
                    Login        = $SamAccountName
                    Prenom       = $row.Prenom
                    Nom          = $row.Nom
                    Statut       = "ABSENT_AD"
                    Detail       = "Present dans le CSV mais absent de l'AD"
                    CSV_Dept     = $row.Departement
                    AD_Dept      = "-"
                    CSV_Societe  = $row.Societe
                    AD_Societe   = "-"
                    CSV_Site     = $row.Site
                    AD_Site      = "-"
                    CSV_Fonction = $row.Fonction
                    AD_Fonction  = "-"
                    OU_Attendue  = $ExpectedOU
                    OU_Actuelle  = "-"
                }
            } else {
                # --- USER PRESENT : comparer les attributs ---
                $diffs = @()
                
                # OU actuelle (on retire le CN= du DN)
                $ActualOU = ($adUser.DistinguishedName -replace '^CN=[^,]+,', '')
                
                # Departement
                if ($row.Departement -and $adUser.Department -ne $row.Departement) {
                    $diffs += "Dept: CSV='$($row.Departement)' / AD='$($adUser.Department)'"
                }
                
                # Societe
                $ExpectedSociete = if ($row.Societe) { $row.Societe } else { "EcoTechSolutions" }
                if ($adUser.Company -and $adUser.Company -ne $ExpectedSociete) {
                    $diffs += "Societe: CSV='$ExpectedSociete' / AD='$($adUser.Company)'"
                }
                
                # Site
                $ExpectedSite = if ($row.Site) { $row.Site } else { "Bordeaux" }
                if ($adUser.Office -and $adUser.Office -ne $ExpectedSite) {
                    $diffs += "Site: CSV='$ExpectedSite' / AD='$($adUser.Office)'"
                }
                
                # Fonction
                if ($row.Fonction -and $adUser.Title -ne $row.Fonction) {
                    $diffs += "Fonction: CSV='$($row.Fonction)' / AD='$($adUser.Title)'"
                }
                
                # OU
                if ($ExpectedOU -notlike "INCONNU*" -and $ActualOU -ne $ExpectedOU) {
                    $diffs += "OU: Attendue='$ExpectedOU' / Actuelle='$ActualOU'"
                }
                
                if ($diffs.Count -gt 0) {
                    # --- DESYNCHRONISE ---
                    $mismatch++
                    Write-Host "  [DESYNC]   $SamAccountName" 
                    foreach ($d in $diffs) {
                        Write-Host "             -> $d" 
                    }
                    
                    $report += [PSCustomObject]@{
                        Login        = $SamAccountName
                        Prenom       = $row.Prenom
                        Nom          = $row.Nom
                        Statut       = "DESYNC"
                        Detail       = ($diffs -join " | ")
                        CSV_Dept     = $row.Departement
                        AD_Dept      = $adUser.Department
                        CSV_Societe  = $ExpectedSociete
                        AD_Societe   = $adUser.Company
                        CSV_Site     = $ExpectedSite
                        AD_Site      = $adUser.Office
                        CSV_Fonction = $row.Fonction
                        AD_Fonction  = $adUser.Title
                        OU_Attendue  = $ExpectedOU
                        OU_Actuelle  = $ActualOU
                    }
                } else {
                    # --- OK ---
                    $ok++
                    Write-Host "  [OK]       $SamAccountName" 
                    
                    $report += [PSCustomObject]@{
                        Login        = $SamAccountName
                        Prenom       = $row.Prenom
                        Nom          = $row.Nom
                        Statut       = "OK"
                        Detail       = "Synchronise"
                        CSV_Dept     = $row.Departement
                        AD_Dept      = $adUser.Department
                        CSV_Societe  = $ExpectedSociete
                        AD_Societe   = $adUser.Company
                        CSV_Site     = $ExpectedSite
                        AD_Site      = $adUser.Office
                        CSV_Fonction = $row.Fonction
                        AD_Fonction  = $adUser.Title
                        OU_Attendue  = $ExpectedOU
                        OU_Actuelle  = $ActualOU
                    }
                }
            }
        }
        
        # =============================================
        # PASSE 2 : Orphelins AD (dans l'AD mais pas dans le CSV)
        # =============================================
        
        Write-Host ""
        Write-Host "--- Recherche d'orphelins AD ---" -ForegroundColor Cyan
        
        $searchBases = @(
            "OU=UX,OU=BDX,OU=ECOTECH,$dn"
            "OU=UX,OU=PAR,OU=UBIHARD,$dn"
            "OU=UX,OU=NTE,OU=STUDIODLIGHT,$dn"
        )
        
        foreach ($base in $searchBases) {
            try {
                $adUsersInOU = Get-ADUser -Filter * -SearchBase $base -SearchScope Subtree `
                                -Properties Department, Company, Office -ErrorAction SilentlyContinue
                
                foreach ($adU in $adUsersInOU) {
                    if ($adU.SamAccountName -notin $csvLogins) {
                        $orphans++
                        Write-Host "  [ORPHELIN] $($adU.SamAccountName) ($($adU.Name))" -ForegroundColor Magenta
                        Write-Host "             -> $base" -ForegroundColor DarkMagenta
                        
                        $report += [PSCustomObject]@{
                            Login        = $adU.SamAccountName
                            Prenom       = $adU.GivenName
                            Nom          = $adU.Surname
                            Statut       = "ORPHELIN_AD"
                            Detail       = "Present dans l'AD mais absent du CSV"
                            CSV_Dept     = "-"
                            AD_Dept      = $adU.Department
                            CSV_Societe  = "-"
                            AD_Societe   = $adU.Company
                            CSV_Site     = "-"
                            AD_Site      = $adU.Office
                            CSV_Fonction = "-"
                            AD_Fonction  = "-"
                            OU_Attendue  = "-"
                            OU_Actuelle  = ($adU.DistinguishedName -replace '^CN=[^,]+,', '')
                        }
                    }
                }
            } catch {
                # OU n'existe pas encore, on passe
            }
        }
        
        # =============================================
        # BILAN FINAL
        # =============================================
        
        Write-Host ""
        Write-Host "============================================="
        Write-Host "            BILAN SYNCHRONISATION            " 
        Write-Host "============================================="
        Write-Host "  Total CSV       : $total"
        Write-Host "  Synchronises    : $ok" -ForegroundColor Green
        Write-Host "  Desynchronises  : $mismatch" -ForegroundColor Yellow
        Write-Host "  Absents de l'AD : $missing" -ForegroundColor Red
        Write-Host "  Orphelins AD    : $orphans" -ForegroundColor Magenta
        Write-Host ""
        
        if ($total -gt 0) {
            $pct = [math]::Round(($ok / $total) * 100, 1)
            $color = if ($pct -ge 90) { "Green" } elseif ($pct -ge 70) { "Yellow" } else { "Red" }
            Write-Host "  Taux de synchro : $pct %" -ForegroundColor $color
        }
        Write-Host ""
        
        # Export CSV si demande
        if ($ExportReport) {
            $timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
            $reportDir = Join-Path -Path (Split-Path $CSVPath -Parent) -ChildPath "Rapports"
            if (-not (Test-Path $reportDir)) { New-Item -ItemType Directory -Path $reportDir -Force | Out-Null }
            
            $reportPath = Join-Path $reportDir "SyncReport_$timestamp.csv"
            $report | Export-Csv -Path $reportPath -NoTypeInformation -Delimiter ";" -Encoding UTF8
            
            Write-Host "  Rapport exporte : $reportPath" -ForegroundColor Cyan
            Write-EcoLog -Message "Rapport sync exporte : $reportPath" -Level Info
        }
        
        Write-EcoLog -Message "Sync Check : $ok OK / $mismatch DESYNC / $missing ABSENTS / $orphans ORPHELINS (sur $total CSV)" -Level Info
        
        return $report
        
    } catch {
        Write-EcoLog -Message "Erreur verification sync : $($_.Exception.Message)" -Level Error
    }
}

function New-EcoTechUser {
    param(
        $Prenom,
        $Nom,
        $Departement,
        $Service,
        $Societe = "EcoTechSolutions",
        $Site = "Bordeaux"
    )
    
    $config = Get-EcoTechConfig
    $dn = $config.DomainInfo.DN
    $SamAccountName = Get-CalculatedLogin -Prenom $Prenom -Nom $Nom
    
    $RootOU = if ($Societe -match "UBIHard") { "UBIHARD" }
              elseif ($Societe -match "Studio") { "STUDIODLIGHT" }
              else { "ECOTECH" }
    
    $SiteOU = if ($Site -match "Paris") { "PAR" }
              elseif ($Site -match "Nantes") { "NTE" }
              else { "BDX" }
    
    $CodeDept = $config.DepartmentMapping[$Departement]
    
    if ($CodeDept) {
        $BaseUserPath = "OU=UX,OU=$SiteOU,OU=$RootOU,$dn"
        $TargetOU = "OU=$CodeDept,$BaseUserPath"
        
        if ($RootOU -eq "ECOTECH") {
            $CodeService = $config.ServiceMapping[$Service]
            if ($CodeService) { $TargetOU = "OU=$CodeService,$TargetOU" }
        }
        
        $pwd = ConvertTo-SecureString $config.DefaultPassword -AsPlainText -Force
        try {
            New-ADUser -Name "$Prenom $Nom" `
                -SamAccountName $SamAccountName `
                -GivenName $Prenom `
                -Surname $Nom `
                -DisplayName "$Prenom $Nom" `
                -UserPrincipalName "$SamAccountName@$($config.DomainInfo.EmailDomain)" `
                -Path $TargetOU `
                -AccountPassword $pwd `
                -Enabled $true `
                -ChangePasswordAtLogon $true `
                -Company $Societe `
                -Office $Site `
                -Department $Departement
            Write-EcoLog -Message "Cree : $SamAccountName dans $TargetOU" -Level Success
        } catch {
            Write-EcoLog -Message "Erreur : $($_.Exception.Message)" -Level Error
        }
    } else {
        Write-EcoLog -Message "Departement inconnu : '$Departement'" -Level Error
    }
}

function Show-UserMenu {
    Clear-Host
    Write-Host "=== GESTION USERS ==="
    Write-Host "1. Import CSV"
    Write-Host "2. Creation manuelle"
    Write-Host "3. Verifier synchronisation"
    Write-Host "Q. Retour"
    
    $c = Read-Host "Choix"
    switch ($c) {
        '1' {
            $p = Read-Host "Chemin CSV"
            if (Test-Path $p) {
                $update = Read-Host "Mettre a jour les users existants ? (O/N)"
                if ($update -eq 'O') {
                    Import-EcoTechUsers -CSVPath $p -UpdateExisting
                } else {
                    Import-EcoTechUsers -CSVPath $p
                }
            } else {
                Write-Host "Fichier introuvable : $p" -ForegroundColor Red
            }
            Pause
        }
        '2' {
            $p   = Read-Host "Prenom"
            $n   = Read-Host "Nom"
            $d   = Read-Host "Departement"
            $s   = Read-Host "Service"
            $soc = Read-Host "Societe (defaut: EcoTechSolutions)"
            $sit = Read-Host "Site (defaut: Bordeaux)"
            if ([string]::IsNullOrWhiteSpace($soc)) { $soc = "EcoTechSolutions" }
            if ([string]::IsNullOrWhiteSpace($sit)) { $sit = "Bordeaux" }
            New-EcoTechUser -Prenom $p -Nom $n -Departement $d -Service $s -Societe $soc -Site $sit
            Pause
        }
        '3' {
            $p = Read-Host "Chemin CSV"
            if (Test-Path $p) {
                $exp = Read-Host "Exporter le rapport en CSV ? (O/N)"
                if ($exp -eq 'O') {
                    Compare-EcoTechSync -CSVPath $p -ExportReport
                } else {
                    Compare-EcoTechSync -CSVPath $p
                }
            } else {
                Write-Host "Fichier introuvable : $p" -ForegroundColor Red
            }
            Pause
        }
    }
}

Export-ModuleMember -Function 'Import-EcoTechUsers', 'New-EcoTechUser', 'Compare-EcoTechSync', 'Show-UserMenu'

```

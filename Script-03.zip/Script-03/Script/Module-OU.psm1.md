
```PowerShell
<#
.SYNOPSIS
    Module de gestion des OUs.
#>

if (-not (Get-Module Module-Common)) {
    Import-Module "$PSScriptRoot\Module-Common.psm1" -ErrorAction Stop
}

function New-EcoTechOUStructure {
    [CmdletBinding(SupportsShouldProcess=$true)]
    param()
    
    Write-EcoLog -Message "Création de l'arborescence OU..." -Level Info
    
    try {
        $config = Get-EcoTechConfig
        $domainDN = $config.DomainInfo.DN
        
        $created = 0
        $skipped = 0
        
        foreach ($ou in $config.OUStructure) {
            # Construction du chemin parent
            if ([string]::IsNullOrWhiteSpace($ou.Parent)) {
                $Path = $domainDN
            } else {
                $Path = "$($ou.Parent),$domainDN"
            }
            
            $existing = Get-ADOrganizationalUnit -Filter "Name -eq '$($ou.Name)'" -SearchBase $Path -SearchScope OneLevel -ErrorAction SilentlyContinue
            # Vérification et Création
            if (-not (Get-ADOrganizationalUnit -Filter "Name -eq '$($ou.Name)'" -SearchBase $Path -ErrorAction SilentlyContinue)) {
                if ($PSCmdlet.ShouldProcess("$($ou.Name) dans $Path", "Créer OU")) {
                    New-ADOrganizationalUnit -Name $ou.Name -Path $Path -Description $ou.Description
                    Write-EcoLog -Message "OU Créée : $($ou.Name)" -Level Success
                }
            }
        }
    } catch {
        Write-EcoLog -Message "Erreur OU Structure : $($_.Exception.Message)" -Level Error
    }
}

function Show-OUMenu {
    Clear-Host
    Write-Host "=== GESTION OU ==="
    Write-Host "1. Initialiser toute l'arborescence"
    Write-Host "Q. Retour"
    
    $c = Read-Host "Choix"
    if ($c -eq '1') { New-EcoTechOUStructure; Pause }
}

Export-ModuleMember -Function 'New-EcoTechOUStructure', 'Show-OUMenu'
```

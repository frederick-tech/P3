
```PowerShell
@{
    # Configuration - EcoTech Solutions & Partenaires

    DomainInfo = @{
        Name = "ecotech.local"
        DN = "DC=ecotech,DC=local"
        NetBIOS = "ECOTECH"
        EmailDomain = "ecotechsolutions.fr"
    }

    DefaultPassword = "EcoTech2026!"

    # Delimiteur du fichier CSV (virgule par defaut)
    CSVDelimiter = ","

    # 1. Mapping Departements (Nom CSV -> Code Dxx)
    # Les cles DOIVENT correspondre exactement aux valeurs du CSV (avec accents)
    DepartmentMapping = @{
        "Direction des Ressources Humaines" = "D01"
        "Service Commercial"                = "D02"
        "Communication"                     = "D03"
        "Direction"                         = "D04"
        "Développement"                     = "D05"
        "Finance et Comptabilité"           = "D06"
        "DSI"                               = "D07"
    }

    # 2. Mapping Services (Nom CSV -> Code Sxx)
    ServiceMapping = @{
        # RH (D01)
        "Formation" = "S01"
        "Recrutement" = "S02"
        "Administration du personnel" = "S03"
        "Gestion des carrières" = "S04"
        "Direction RH" = "S05"

        # Commercial (D02)
        "Gestion des comptes" = "S01"
        "B2B" = "S02"
        "Prospection" = "S03"
        "ADV" = "S04"
        "Service Client" = "S05"
        "Service achat" = "S06"
        "Direction commerciale" = "S07"

        # Communication (D03)
        "Relation Médias" = "S01"
        "Communication externe" = "S02"
        "Communication interne" = "S03"
        "Événementiel" = "S04"
        "Gestion des réseaux sociaux" = "S05"
        "Direction Communication" = "S06"

        # Direction (D04)
        "Direction Générale" = "S01"
        "Direction adjoint" = "S02"
        "Responsable stratégie" = "S03"
        "Assistant de direction" = "S04"

        # Developpement (D05)
        "Développement frontend" = "S01"
        "Développement fronted" = "S01"
        "Développement backend" = "S02"
        "Développement mobile" = "S03"
        "Analyse et conception" = "S04"
        "Tests et qualité" = "S05"
        "Direction Développement" = "S06"
        "Recherche et Prototype" = "S07"

        # Finance (D06)
        "Finance" = "S01"
        "Fiscalité" = "S02"
        "Service Comptabilité" = "S03"
        "Direction financière" = "S04"

        # DSI (D07)
        "Exploitation" = "S01"
        "Direction SI" = "S02"
    }

    # 3. Structure ARBORESCENCE (Creation par Module-OU)
    OUStructure = @(
        # === ECOTECH SOLUTIONS (Bordeaux) ===
        @{Name="ECOTECH"; Description="Racine Organisation"; Parent=""}
        @{Name="BDX";     Description="Site Bordeaux";       Parent="OU=ECOTECH"}

        # Zones
        @{Name="GX"; Description="Administration"; Parent="OU=BDX,OU=ECOTECH"}
        @{Name="UX"; Description="Utilisateurs";   Parent="OU=BDX,OU=ECOTECH"}
        @{Name="SX"; Description="Securite";        Parent="OU=BDX,OU=ECOTECH"}
        @{Name="WX"; Description="Workstations";   Parent="OU=BDX,OU=ECOTECH"}

        # Sous-dossiers WX
        @{Name="BX"; Description="Fixes";      Parent="OU=WX,OU=BDX,OU=ECOTECH"}
        @{Name="CX"; Description="Portables";  Parent="OU=WX,OU=BDX,OU=ECOTECH"}
        @{Name="EX"; Description="Serveurs";   Parent="OU=WX,OU=BDX,OU=ECOTECH"}
        @{Name="FX"; Description="Appliances"; Parent="OU=WX,OU=BDX,OU=ECOTECH"}

        # Departements UX (D01..D07)
        @{Name="D01"; Parent="OU=UX,OU=BDX,OU=ECOTECH"}
        @{Name="D02"; Parent="OU=UX,OU=BDX,OU=ECOTECH"}
        @{Name="D03"; Parent="OU=UX,OU=BDX,OU=ECOTECH"}
        @{Name="D04"; Parent="OU=UX,OU=BDX,OU=ECOTECH"}
        @{Name="D05"; Parent="OU=UX,OU=BDX,OU=ECOTECH"}
        @{Name="D06"; Parent="OU=UX,OU=BDX,OU=ECOTECH"}
        @{Name="D07"; Parent="OU=UX,OU=BDX,OU=ECOTECH"}

        # Departements SX (Groupes) (D01..D07)
        @{Name="D01"; Parent="OU=SX,OU=BDX,OU=ECOTECH"}
        @{Name="D02"; Parent="OU=SX,OU=BDX,OU=ECOTECH"}
        @{Name="D03"; Parent="OU=SX,OU=BDX,OU=ECOTECH"}
        @{Name="D04"; Parent="OU=SX,OU=BDX,OU=ECOTECH"}
        @{Name="D05"; Parent="OU=SX,OU=BDX,OU=ECOTECH"}
        @{Name="D06"; Parent="OU=SX,OU=BDX,OU=ECOTECH"}
        @{Name="D07"; Parent="OU=SX,OU=BDX,OU=ECOTECH"}

        # Services UX (Sxx sous Dxx)
        # D01 (RH) - S01..S05
        @{Name="S01"; Parent="OU=D01,OU=UX,OU=BDX,OU=ECOTECH"}
        @{Name="S02"; Parent="OU=D01,OU=UX,OU=BDX,OU=ECOTECH"}
        @{Name="S03"; Parent="OU=D01,OU=UX,OU=BDX,OU=ECOTECH"}
        @{Name="S04"; Parent="OU=D01,OU=UX,OU=BDX,OU=ECOTECH"}
        @{Name="S05"; Parent="OU=D01,OU=UX,OU=BDX,OU=ECOTECH"}

        # D02 (Commercial) - S01..S07
        @{Name="S01"; Parent="OU=D02,OU=UX,OU=BDX,OU=ECOTECH"}
        @{Name="S02"; Parent="OU=D02,OU=UX,OU=BDX,OU=ECOTECH"}
        @{Name="S03"; Parent="OU=D02,OU=UX,OU=BDX,OU=ECOTECH"}
        @{Name="S04"; Parent="OU=D02,OU=UX,OU=BDX,OU=ECOTECH"}
        @{Name="S05"; Parent="OU=D02,OU=UX,OU=BDX,OU=ECOTECH"}
        @{Name="S06"; Parent="OU=D02,OU=UX,OU=BDX,OU=ECOTECH"}
        @{Name="S07"; Parent="OU=D02,OU=UX,OU=BDX,OU=ECOTECH"}

        # D03 (Communication) - S01..S06
        @{Name="S01"; Parent="OU=D03,OU=UX,OU=BDX,OU=ECOTECH"}
        @{Name="S02"; Parent="OU=D03,OU=UX,OU=BDX,OU=ECOTECH"}
        @{Name="S03"; Parent="OU=D03,OU=UX,OU=BDX,OU=ECOTECH"}
        @{Name="S04"; Parent="OU=D03,OU=UX,OU=BDX,OU=ECOTECH"}
        @{Name="S05"; Parent="OU=D03,OU=UX,OU=BDX,OU=ECOTECH"}
        @{Name="S06"; Parent="OU=D03,OU=UX,OU=BDX,OU=ECOTECH"}

        # D04 (Direction) - S01..S04
        @{Name="S01"; Parent="OU=D04,OU=UX,OU=BDX,OU=ECOTECH"}
        @{Name="S02"; Parent="OU=D04,OU=UX,OU=BDX,OU=ECOTECH"}
        @{Name="S03"; Parent="OU=D04,OU=UX,OU=BDX,OU=ECOTECH"}
        @{Name="S04"; Parent="OU=D04,OU=UX,OU=BDX,OU=ECOTECH"}

        # D05 (Developpement) - S01..S07 (S07 = Recherche et Prototype)
        @{Name="S01"; Parent="OU=D05,OU=UX,OU=BDX,OU=ECOTECH"}
        @{Name="S02"; Parent="OU=D05,OU=UX,OU=BDX,OU=ECOTECH"}
        @{Name="S03"; Parent="OU=D05,OU=UX,OU=BDX,OU=ECOTECH"}
        @{Name="S04"; Parent="OU=D05,OU=UX,OU=BDX,OU=ECOTECH"}
        @{Name="S05"; Parent="OU=D05,OU=UX,OU=BDX,OU=ECOTECH"}
        @{Name="S06"; Parent="OU=D05,OU=UX,OU=BDX,OU=ECOTECH"}
        @{Name="S07"; Parent="OU=D05,OU=UX,OU=BDX,OU=ECOTECH"}

        # D06 (Finance) - S01..S04
        @{Name="S01"; Parent="OU=D06,OU=UX,OU=BDX,OU=ECOTECH"}
        @{Name="S02"; Parent="OU=D06,OU=UX,OU=BDX,OU=ECOTECH"}
        @{Name="S03"; Parent="OU=D06,OU=UX,OU=BDX,OU=ECOTECH"}
        @{Name="S04"; Parent="OU=D06,OU=UX,OU=BDX,OU=ECOTECH"}

        # D07 (DSI) - S01..S02
        @{Name="S01"; Parent="OU=D07,OU=UX,OU=BDX,OU=ECOTECH"}
        @{Name="S02"; Parent="OU=D07,OU=UX,OU=BDX,OU=ECOTECH"}

        # === UBIHARD (Paris) ===
        @{Name="UBIHARD"; Description="Partenaire UBIHard"; Parent=""}
        @{Name="PAR";     Description="Site Paris";          Parent="OU=UBIHARD"}

        @{Name="UX"; Description="Utilisateurs PAR"; Parent="OU=PAR,OU=UBIHARD"}
        @{Name="WX"; Description="Postes PAR";       Parent="OU=PAR,OU=UBIHARD"}
        @{Name="SX"; Description="Securite PAR";     Parent="OU=PAR,OU=UBIHARD"}
        @{Name="GX"; Description="Admin PAR";        Parent="OU=PAR,OU=UBIHARD"}

        @{Name="D05"; Description="Dev Paris"; Parent="OU=UX,OU=PAR,OU=UBIHARD"}

        # === STUDIO DLIGHT (Nantes) ===
        @{Name="STUDIODLIGHT"; Description="Partenaire Studio Dlight"; Parent=""}
        @{Name="NTE";          Description="Site Nantes";              Parent="OU=STUDIODLIGHT"}

        @{Name="UX"; Description="Utilisateurs NTE"; Parent="OU=NTE,OU=STUDIODLIGHT"}
        @{Name="WX"; Description="Postes NTE";       Parent="OU=NTE,OU=STUDIODLIGHT"}
        @{Name="SX"; Description="Securite NTE";     Parent="OU=NTE,OU=STUDIODLIGHT"}
        @{Name="GX"; Description="Admin NTE";        Parent="OU=NTE,OU=STUDIODLIGHT"}

        @{Name="D05"; Description="Dev Nantes"; Parent="OU=UX,OU=NTE,OU=STUDIODLIGHT"}
    )
}

```
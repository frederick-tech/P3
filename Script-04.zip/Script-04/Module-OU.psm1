<#
.SYNOPSIS
    Module de gestion des OUs.
#>

if (-not (Get-Module Module-Common)) {
    Import-Module "$PSScriptRoot\Module-Common.psm1" -ErrorAction Stop
}

function New-EcoTechOUStructure {
    [CmdletBinding(SupportsShouldProcess=$true)]
    param()
    
    Write-EcoLog -Message "Création de l'arborescence OU..." -Level Info
    
    try {
        $config = Get-EcoTechConfig
        $domainDN = $config.DomainInfo.DN
        
        $created = 0
        $skipped = 0
        
		foreach ($ou in $config.OUStructure) {
			$Path = if ([string]::IsNullOrWhiteSpace($ou.Parent)) {
			$domainDN } else { "$($ou.Parent),$domainDN" 
			}
            
            # On cherche si l'OU existe
			$existing = Get-ADOrganizationalUnit -Filter "Name -eq'$($ou.Name)'" -SearchBase $Path -SearchScope OneLevel -ErrorAction SilentlyContinue

            if ($existing) {
                # Elle existe : On met à jour la description
                Set-ADOrganizationalUnit -Identity $existing.DistinguishedName -Description $ou.Description
            } else {
                # Elle n'existe pas : On la crée
                if ($PSCmdlet.ShouldProcess("$($ou.Name)", "Créer OU avec description")) {
                    New-ADOrganizationalUnit -Name $ou.Name -Path $Path -Description $ou.Description
                    Write-EcoLog -Message "OU Créée : $($ou.Name)" -Level Success
                }
            }
        }
    } catch {
        Write-EcoLog -Message "Erreur OU Structure : $($_.Exception.Message)" -Level Error
    }
}

function Show-OUMenu {
    Clear-Host
    Write-Host "=== GESTION OU ==="
    Write-Host "1. Initialiser toute l'arborescence"
    Write-Host "Q. Retour"
    
    $c = Read-Host "Choix"
    if ($c -eq '1') { New-EcoTechOUStructure; Pause }
}

Export-ModuleMember -Function 'New-EcoTechOUStructure', 'Show-OUMenu'

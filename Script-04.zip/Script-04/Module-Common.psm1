<#
.SYNOPSIS
    Module de fonctions communes pour la gestion Active Directory d'EcoTech Solutions

.DESCRIPTION
    Contient les fonctions transverses :
    - Gestion de la configuration
    - Logging centralisé
    - Normalisation des chaînes (Nettoyage d'accents)
    - Génération des Logins (Format: 2 lettres Prénom + Nom)

.NOTES
    Auteur: Équipe G2
#>

#region Variables globales du module
$Script:Config = $null
$Script:LogFile = $null
#endregion

#region 1. Fonctions de Manipulation de Texte

function Get-CleanString {
    <#
    .DESCRIPTION
        Nettoyage avancé pour compatibilité AD (SamAccountName).
        Gère les ligatures (œ, æ, ß), les accents celtiques/européens, et supprime les caractères spéciaux.
    #>
    param([string]$Text)

    if ([string]::IsNullOrWhiteSpace($Text)) { return "" }

    # 1. Remplacement manuel des ligatures et caractères spéciaux non décomposables
    $Text = $Text -replace 'œ', 'oe' `
                  -replace 'Œ', 'OE' `
                  -replace 'æ', 'ae' `
                  -replace 'Æ', 'AE' `
                  -replace 'ß', 'ss' `
                  -replace 'ø', 'o' `
                  -replace 'Ø', 'O' `
                  -replace 'ł', 'l' `
                  -replace 'Ł', 'L'

    # 2. Normalisation Unicode (Form D)
    #    Cela sépare la lettre de base de son accent.
    #    Ex: 'ŷ' (gallois) devient 'y' + 'accent circonflexe'
    #    Ex: 'ñ' (breton) devient 'n' + 'tilde'
    $Text = $Text.Normalize([System.Text.NormalizationForm]::FormD)

    # 3. Supprime la catégorie "Mn" (Mark, Nonspacing)
    #    C'est ici qu'on "tue" tous les accents flottants séparés à l'étape 2.
    $Text = $Text -replace '\p{Mn}', ''

    # 4. Nettoyage final : On ne garde que les lettres (a-z) et les chiffres (0-9)
    #    On supprime les tirets, apostrophes, espaces, etc.
    $Text = $Text -replace '[^a-zA-Z0-9]', ''

    # 5. Retourne en minuscule
    return $Text.ToLower()
}

function Get-CalculatedLogin {
    <#
    .DESCRIPTION
        Génère le login selon la nomenclature : 2 premières lettres du Prénom + Nom complet.
        Le tout est nettoyé (sans accent) et limité à 20 caractères (limite AD).
    #>
    param(
        [string]$Prenom, 
        [string]$Nom
    )
    
    # Nettoyage préalable des entrées pour éviter les espaces vides
    $Prenom = ($Prenom -as [string]).Trim()
    $Nom    = ($Nom -as [string]).Trim()
    
    # Logique : 2 premières lettres du prénom
    if ($Prenom.Length -ge 2) { 
        $P2 = $Prenom.Substring(0,2) 
    } else { 
        $P2 = $Prenom 
    }
    
    # Concaténation
    $RawLogin = $P2 + $Nom
    
    # Nettoyage final (accents, espaces -> minuscules)
    $FinalLogin = Get-CleanString -Text $RawLogin

    # Sécurité : Tronquer à 20 caractères (Limite SamAccountName AD)
    if ($FinalLogin.Length -gt 20) {
        $FinalLogin = $FinalLogin.Substring(0, 20)
    }

    return $FinalLogin
}
#endregion

#region 2. Fonctions de Configuration

function Import-EcoTechConfig {
    param([string]$ConfigPath)
    
    if (-not (Test-Path $ConfigPath)) {
        throw "Fichier de configuration introuvable : $ConfigPath"
    }

    try {
        Write-Host "Chargement de la configuration..." 
        
        # 1. Lecture du fichier .psd1 (Structure de base)
        $RawContent = Get-Content -Path $ConfigPath -Raw -Encoding UTF8
        $Script:Config = Invoke-Expression $RawContent
        
        if (-not ($Script:Config -is [hashtable])) {
            throw "Le fichier n'est pas valide."
        }

        # 2. DÉTECTION DYNAMIQUE DU DOMAINE
        # On écrase les valeurs du fichier par celles de l'AD actuel
        try {
            # On récupère les infos du domaine courant
            $CurrentAD = Get-ADDomain
            
            Write-Host "Détection de l'environnement Active Directory..."
            
            # Injection des vraies valeurs
            $ad = Get-ADDomain
            $Script:Config.DomainInfo.Name    = $CurrentAD.DNSRoot 
            $Script:Config.DomainInfo.DN      = $CurrentAD.DistinguishedName
            $Script:Config.DomainInfo.NetBIOS = $CurrentAD.NetBIOSName       
            $Script:Config.DomainInfo.EmailDomain = $CurrentAD.DNSRoot
            
            Write-Host "  > Domaine : $($CurrentAD.DNSRoot)" 
            Write-Host "  > Racine  : $($CurrentAD.DistinguishedName)" 
            
        } catch {
            Write-Host "ATTENTION : Impossible de détecter le domaine AD." 
            Write-Host "Le script utilise les valeurs par défaut du fichier config." 
        }

        return $Script:Config

    } catch {
        Write-Host "ERREUR FATALE CONFIG : $($_.Exception.Message)" -ForegroundColor Red
        throw
    }
}

function Get-EcoTechConfig {
    # Retourne la config déjà chargée en mémoire
    if ($null -eq $Script:Config) {
        throw "La configuration n'a pas été chargée. Lancez Import-EcoTechConfig d'abord."
    }
    return $Script:Config
}
#endregion

#region 3. Fonctions de Logging

function Initialize-LogFile {
    param([string]$LogPath)
    $Script:LogFile = $LogPath
    $Dir = Split-Path -Parent $LogPath
    
    if (-not (Test-Path $Dir)) { 
	    New-Item -ItemType Directory -Path $Dir -Force | Out-Null 
	}
    if (-not (Test-Path $LogPath)) { 
	    "Date;Level;Message" | Out-File $LogPath -Encoding UTF8 
	}
}

function Write-EcoLog {
    param($Message, $Level = 'Info')
    $Date = Get-Date -Format "yyyy-MM-dd HH:mm:ss"

    $Color = switch ($Level) {
        'Error'   { 'Red' }
        'Success' { 'Green' }
        'Warning' { 'Yellow' }
        Default   { 'Gray' }
    }
    Write-Host "[$Level] $Message" -ForegroundColor $Color

    if ($Script:LogFile) {
        "$Date;$Level;$Message" | Out-File $Script:LogFile -Append -Encoding UTF8
    }
}

function Show-EcoTechStatus {
    Write-Host "Domaine: $env:USERDNSDOMAIN | User: $env:USERNAME" 
}
#endregion

# Exporter toutes les fonctions pour qu'elles soient visibles
Export-ModuleMember -Function @(
    'Get-CleanString',
    'Get-CalculatedLogin',
    'Import-EcoTechConfig',
    'Get-EcoTechConfig',
    'Initialize-LogFile',
    'Write-EcoLog',
    'Show-EcoTechStatus'
)

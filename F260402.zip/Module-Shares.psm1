<#
.SYNOPSIS
    Module de gestion des partages et permissions NTFS - EcoTech

.NOTES
    Auteur: Équipe G2
#>

function New-EcoTechSharesStructure {
    param(
        [string]$RootPath = "D:\Partages"
    )
    $config = Get-EcoTechConfig
    
    # 1. Création des racines si inexistantes
    $Paths = @("Users", "Services", "Departments")
    foreach ($p in $Paths) {
        $full = Join-Path $RootPath $p
        if (-not (Test-Path $full)) { 
            New-Item -ItemType Directory -Path $full -Force | Out-Null
            Write-EcoLog -Message "Racine créée : $full" -Level Success
        }
    }

    # 2. Création des dossiers de Départements (Lecteur K)
    Write-Host "--- Configuration des dossiers Départements ---" -ForegroundColor Cyan
    foreach ($deptName in $config.DepartmentMapping.Keys) {
        $code = $config.DepartmentMapping[$deptName]
        $folderPath = Join-Path $RootPath "Departments\$deptName"
        
        if (-not (Test-Path $folderPath)) {
            New-Item -ItemType Directory -Path $folderPath -Force | Out-Null
            
            # Application des permissions NTFS au groupe GRP_Dxx
            $GroupName = "GRP_$($code)_*" 
            $ADGroup = Get-ADGroup -Filter "Name -like '$GroupName'"
            
            if ($ADGroup) {
                $acl = Get-Acl $folderPath
                $permission = "$($config.DomainInfo.NetBIOS)\$($ADGroup.Name)","Modify","ContainerInherit,ObjectInherit","None","Allow"
                $accessRule = New-Object System.Security.AccessControl.FileSystemAccessRule $permission
                $acl.SetAccessRule($accessRule)
                Set-Acl $folderPath $acl
                Write-EcoLog -Message "Permissions K: configurées pour $deptName" -Level Success
            }
        }
    }
}

function Install-EcoTechFileShares {
    param(
        [string]$ServerPath = "C:\Shares"
    )
    
    $config = Get-EcoTechConfig
    $netbios = $config.DomainInfo.NetBIOS

    # 1. Création des dossiers racines
    $roots = @("Users$", "Services$", "Departments$")
    foreach ($r in $roots) {
        $p = Join-Path $ServerPath $r
        if (-not (Test-Path $p)) { New-Item -ItemType Directory -Path $p -Force }
    }

    # 2. Dossiers de Départements (K:)
    foreach ($dept in $config.DepartmentMapping.Keys) {
        $code = $config.DepartmentMapping[$dept]
        $folder = Join-Path $ServerPath "Departments$\$dept"
        if (-not (Test-Path $folder)) { New-Item -ItemType Directory -Path $folder }
        
        # Droit : GRP_Dxx -> Modification
        $group = "GRP_$code*"
        $adGroup = Get-ADGroup -Filter "Name -like '$group'"
        if ($adGroup) {
            $acl = Get-Acl $folder
            $rule = New-Object System.Security.AccessControl.FileSystemAccessRule("$netbios\$($adGroup.Name)","Modify","ContainerInherit,ObjectInherit","None","Allow")
            $acl.SetAccessRule($rule)
            Set-Acl $folder $acl
        }
    }
    
    Write-EcoLog -Message "Structure des partages K: et J: configurée avec succès." -Level Success
}

# Exporter toutes les fonctions pour qu'elles soient visibles
Export-ModuleMember -Function @(
    'Install-EcoTechFileShares',
    'New-EcoTechLogonScript',
    'Show-ShareMenu'
)
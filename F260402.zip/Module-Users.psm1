<#
.SYNOPSIS
    Module de gestion des utilisateurs pour EcoTech Solutions (Multi-Societes & Services)

.DESCRIPTION
    Gere le cycle de vie des utilisateurs :
    - Importation CSV intelligente (mapping Departements -> OU)
    - Gestion dynamique des attributs
    - Creation unitaire
    - Generation automatique des logins
    - Verification de synchronisation CSV <-> AD

.NOTES
    Auteur: Equipe G2
#>

if (-not (Get-Module Module-Common)) {
    Import-Module "$PSScriptRoot\Module-Common.psm1" -ErrorAction Stop
}

#region UTILITAIRES INTERNES

function Get-CSVDelimiter {
    param([string]$Path)
    $firstLine = Get-Content $Path -TotalCount 1
    if ($firstLine -match ";") { return ";" } else { return "," }
}

#endregion

#region 1. IMPORTATION ET GÉNÉRATION DE RAPPORT

function Import-EcoTechUsers {
    [CmdletBinding(SupportsShouldProcess=$true)]
    param(
        [string]$CSVPath = "Fiche_personnels.csv",
        [switch]$UpdateExisting
    )
    
    # Résolution du chemin
    if (-not (Split-Path $CSVPath)) { $CSVPath = Join-Path $PSScriptRoot $CSVPath }
    if (-not (Test-Path $CSVPath)) { Write-EcoLog -Message "Fichier introuvable : $CSVPath" -Level Error; return }

    $config = Get-EcoTechConfig
    $dn = $config.DomainInfo.DN
    $defaultPassword = ConvertTo-SecureString $config.DefaultPassword -AsPlainText -Force
    
    # Lecture du CSV (Délimiteur automatique)
    $delim = Get-CSVDelimiter -Path $CSVPath
    $users = Import-Csv -Path $CSVPath -Delimiter $delim -Encoding UTF8
    $srvFiles = $config.SharesConfig.FileServer

    $report = @()
    $total = $users.Count
    $current = 0

    Write-Host "--- IMPORTATION EN COURS ($total utilisateurs) ---" -ForegroundColor Cyan

    foreach ($row in $users) {
        $current++
        Write-Progress -Activity "Importation Active Directory" -Status "Utilisateur : $($row.Prenom) $($row.Nom)" -PercentComplete (($current / $total) * 100)

        # Initialisation ligne de rapport
        $logEntry = [PSCustomObject]@{
            Nom      = "$($row.Prenom) $($row.Nom)"
            Login    = ""
            Statut   = "Echec"
            Message  = ""
            Date     = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
        }

        try {
            if ([string]::IsNullOrWhiteSpace($row.Nom)) { throw "Nom manquant dans le CSV" }
			# 1. Génèration de la base (ex: anboutaleb)
			$BaseSam = Get-CalculatedLogin -Prenom $row.Prenom -Nom $row.Nom
            $Sam = $BaseSam

            # 2. Detection homonyme
            $Index = 1
            while (Get-ADUser -Filter "SamAccountName -eq '$Sam'" -ErrorAction SilentlyContinue) {
                # Si l'utilisateur existe déjà mais qu'on ne veut pas le mettre à jour, on cherche le prochain login libre (anboutaleb1, anboutaleb2...)
                if (-not $UpdateExisting) {
                    $Sam = $BaseSam + $Index
                    $Index++
                } else {
                    # Si UpdateExisting est activé, on arrête la boucle pour modifier l'existant
                    break 
                }
            }
            $logEntry.Login = $Sam

            # Nettoyage
            $NomDept = if ($row.Departement) { $row.Departement.Trim() } else { "" }
            $NomServ = if ($row.Service)     { $row.Service.Trim() }     else { "" }

            # 4. Mapping Departement
            $CodeDept = if ($config.DepartmentMapping.ContainsKey($NomDept)) { $config.DepartmentMapping[$NomDept] } else { $null }
            if (-not $CodeDept) { throw "Departement inconnu : '$NomDept'" }

            # 5. Mapping Service (ServiceMapping = @{Code="Sxx"; Dept="Dxx"})
            $CodeServ = $null
            if ($NomServ -and $config.ServiceMapping.ContainsKey($NomServ)) {
                $svcInfo = $config.ServiceMapping[$NomServ]
                if ($svcInfo -is [hashtable]) { $CodeServ = $svcInfo.Code }
                else { $CodeServ = $svcInfo }
            }

            # 6. Détermination Racine / Site
            $RootOU = switch -Wildcard ($row.Societe) {
                "*UBIHard*"       { "UBIHARD" }
                "*Studio Dlight*" { "STUDIODLIGHT" }
                Default           { "ECOTECH" }
            }
            $SiteOU = switch -Wildcard ($row.Site) {
                "*Paris*"  { "PAR" }
                "*Nantes*" { "NTE" }
                Default    { "BDX" }
            }

            $BasePath = "OU=UX,OU=$SiteOU,OU=$RootOU,$dn"
            $TargetOU = if ($CodeServ) { "OU=$CodeServ,OU=$CodeDept,$BasePath" } else { "OU=$CodeDept,$BasePath" }

            # 7. Parametres AD
            $UserParams = @{
                Name                  = "$($row.Prenom) $($row.Nom)"
                SamAccountName        = $Sam
                DisplayName           = "$($row.Prenom) $($row.Nom)"
                GivenName             = $row.Prenom
                Surname               = $row.Nom
                UserPrincipalName     = "$Sam@$($config.DomainInfo.EmailDomain)"
                EmailAddress          = "$Sam@$($config.DomainInfo.EmailDomain)"
                Path                  = $TargetOU
                AccountPassword       = $defaultPassword
                Enabled               = $true
                ChangePasswordAtLogon = $true
                Company               = $row.Societe
                Department            = $NomDept
                Title                 = $row.fonction
                OfficePhone           = $row.'Telephone fixe'
                MobilePhone           = $row.'Telephone portable'
                Description           = "Service: $NomServ"
                HomeDrive             = "I:"
                HomeDirectory         = "\\$srvFiles\Users$\$Sam"
                ErrorAction           = "Stop"
            }

            # 8. Execution
            $existingUser = Get-ADUser -Filter "SamAccountName -eq '$Sam'" -ErrorAction SilentlyContinue
            
            if (-not (Get-ADUser -Filter "SamAccountName -eq '$Sam'" -ErrorAction SilentlyContinue)) {
                if ($PSCmdlet.ShouldProcess($Sam, "Créer")) {
                    New-ADUser @UserParams
                    $logEntry.Statut = "Cree"
                    $logEntry.Message = "Succès dans $TargetOU"
                }
            } elseif ($UpdateExisting) {
                Set-ADUser -Identity $Sam `
                    -Company $row.Societe `
                    -Department $NomDept `
                    -Title $row.fonction `
                    -OfficePhone $row.'Telephone fixe' `
                    -MobilePhone $row.'Telephone portable' `
                    -Description "Service: $NomServ"
                $logEntry.Statut = "Mis a jour"
                $logEntry.Message = "Propriétés actualisées"
            } else {
                $logEntry.Statut = "Existant"
                $logEntry.Message = "Déjà présent, aucune modification"
            }
        } catch {
            $logEntry.Message = $_.Exception.Message
            Write-EcoLog -Message "Erreur $($row.Nom) : $($_.Exception.Message)" -Level Error
        }
        $report += $logEntry
    }

    # Rapport CSV
    $reportDir = Join-Path $PSScriptRoot "Rapports"
    if (-not (Test-Path $reportDir)) { New-Item -ItemType Directory -Path $reportDir -Force | Out-Null }
    $reportFile = Join-Path $reportDir "Rapport_Import_$(Get-Date -Format 'yyyyMMdd_HHmm').csv"
    $report | Export-Csv -Path $reportFile -NoTypeInformation -Delimiter ";" -Encoding UTF8

    # Bilan console
    $crees   = @($report | Where-Object { $_.Statut -eq "Cree" }).Count
    $maj     = @($report | Where-Object { $_.Statut -eq "Mis a jour" }).Count
    $erreurs = @($report | Where-Object { $_.Statut -eq "Echec" }).Count
    Write-Host ""
    Write-EcoLog -Message "BILAN : $crees crees | $maj MAJ | $erreurs erreurs" -Level Info
    Write-Host "Rapport : $reportFile" -ForegroundColor Cyan
}

#endregion

#region 2. SYNCHRONISATION (MANAGERS & GROUPES)

function Sync-EcoTechManagers {
    param([string]$CSVPath = "Fiche_personnels.csv")
    
    if (-not (Split-Path $CSVPath)) { $CSVPath = Join-Path $PSScriptRoot $CSVPath }
    if (-not (Test-Path $CSVPath)) { Write-EcoLog -Message "CSV introuvable : $CSVPath" -Level Error; return }

    $delim = Get-CSVDelimiter -Path $CSVPath
    $users = Import-Csv $CSVPath -Delimiter $delim -Encoding UTF8
    $linked = 0

    Write-Host "--- LIAISON DES MANAGERS ---" -ForegroundColor Cyan

    foreach ($row in $users) {
        if ([string]::IsNullOrWhiteSpace($row.'Manager-Nom')) { continue }

        $userSam = Get-CalculatedLogin -Prenom $row.Prenom -Nom $row.Nom
        $mgrSam  = Get-CalculatedLogin -Prenom $row.'Manager-Prenom' -Nom $row.'Manager-Nom'

        try {
            $mgrAD = Get-ADUser -Filter "SamAccountName -eq '$mgrSam'" -ErrorAction Stop
            if (-not $mgrAD) { throw "Manager $mgrSam introuvable" }
            Set-ADUser -Identity $userSam -Manager $mgrAD.DistinguishedName -ErrorAction Stop
            $linked++
        } catch {
            Write-EcoLog -Message "Manager : $mgrSam introuvable pour $userSam" -Level Warning
        }
    }

    Write-EcoLog -Message "Managers lies : $linked" -Level Info
}

function Invoke-EcoTechGroupSync {
    <#
    .DESCRIPTION
        Synchronise les utilisateurs AD vers les groupes GRP-UX-Dxx
        en se basant sur l'attribut Department de chaque user.
    #>
    Write-Host "--- SYNCHRONISATION GROUPES ---" -ForegroundColor Cyan
    $config = Get-EcoTechConfig
    $added = 0

    $adUsers = Get-ADUser -Filter 'Company -like "*"' -Properties Department -ErrorAction SilentlyContinue
    foreach ($u in $adUsers) {
        $code = $config.DepartmentMapping[$u.Department]
        if ($code) {
            $groupName = "GRP-UX-$code"
            $group = Get-ADGroup -Filter "Name -eq '$groupName'" -ErrorAction SilentlyContinue
            if ($group) {
                try {
                    Add-ADGroupMember -Identity $group -Members $u -ErrorAction SilentlyContinue
                    $added++
                } catch { }
            }
        }
    }

    Write-EcoLog -Message "Synchro groupes terminee ($added associations)." -Level Info
}

#endregion

#region 3. AUDIT ET SYNCHRONISATION

function Compare-EcoTechSync {
    [CmdletBinding()]
    param([string]$CSVPath = "Fiche_personnels.csv")

    $config = Get-EcoTechConfig
    $dn = $config.DomainInfo.DN
    if (-not (Split-Path $CSVPath)) { $CSVPath = Join-Path $PSScriptRoot $CSVPath }
    if (-not (Test-Path $CSVPath)) { Write-EcoLog -Message "CSV introuvable" -Level Error; return }
    # Détection automatique du délimiteur
    $delim = Get-CSVDelimiter -Path $CSVPath
    $csvUsers = Import-Csv $CSVPath -Delimiter $delim -Encoding UTF8
    $results = @()
    $csvLogins = @()
    $ok = 0; $absent = 0; $desync = 0; $orphelins = 0

    Write-Host ""
    Write-Host "============================================="
    Write-Host "       VERIFICATION SYNCHRO CSV <-> AD       "
    Write-Host "=============================================" 

    foreach ($row in $csvUsers) {
        $Sam = Get-CalculatedLogin -Prenom $row.Prenom -Nom $row.Nom
        $csvLogins += $Sam
        # On demande les propriétés étendues pour la comparaison
        $adUser = Get-ADUser -Filter "SamAccountName -eq '$Sam'" `
                  -Properties Department, Company, Office, Title, OfficePhone, MobilePhone `
                  -ErrorAction SilentlyContinue

        $diffs = @()
        if (-not $adUser) {
            $status = "ABSENT"
            $absent++
            Write-Host "  [ABSENT]  $Sam ($($row.Prenom) $($row.Nom))" -ForegroundColor Red
        } else {
            if ($adUser.Department -ne $row.Departement) { $diffs += "Dept" }
            if ($adUser.Company -ne $row.Societe)        { $diffs += "Societe" }
            if ($adUser.Title -ne $row.fonction)          { $diffs += "Fonction" }
            if ($adUser.OfficePhone -ne $row.'Telephone fixe') { $diffs += "Tel" }

            if ($diffs.Count -gt 0) {
                $status = "DESYNC ($($diffs -join ','))"
                $desync++
                Write-Host "  [DESYNC]  $Sam -> $($diffs -join ', ')" -ForegroundColor Yellow
            } else {
                $status = "OK"
                $ok++
            }
        }

        $results += [PSCustomObject]@{ Login = $Sam; Nom = "$($row.Prenom) $($row.Nom)"; Statut = $status }
    }

    # Orphelins AD
    Write-Host ""
    Write-Host "--- Recherche orphelins AD ---" -ForegroundColor Cyan
    $searchBases = @(
        "OU=UX,OU=BDX,OU=ECOTECH,$dn"
        "OU=UX,OU=PAR,OU=UBIHARD,$dn"
        "OU=UX,OU=NTE,OU=STUDIODLIGHT,$dn"
    )
    foreach ($base in $searchBases) {
        try {
            Get-ADUser -Filter * -SearchBase $base -SearchScope Subtree -ErrorAction Stop | ForEach-Object {
                if ($_.SamAccountName -notin $csvLogins) {
                    $orphelins++
                    Write-Host "  [ORPHELIN] $($_.SamAccountName) ($($_.Name))" -ForegroundColor Magenta
                    $results += [PSCustomObject]@{ Login = $_.SamAccountName; Nom = $_.Name; Statut = "ORPHELIN" }
                }
            }
        } catch { }
    }

    # Bilan
    $total = $csvUsers.Count
    Write-Host ""
    Write-Host "=============================================" -ForegroundColor Cyan
    Write-Host "  Total CSV    : $total"
    Write-Host "  OK           : $ok" -ForegroundColor Green
    Write-Host "  Desync       : $desync" -ForegroundColor Yellow
    Write-Host "  Absents AD   : $absent" -ForegroundColor Red
    Write-Host "  Orphelins    : $orphelins" -ForegroundColor Magenta
    if ($total -gt 0) {
        $pct = [math]::Round(($ok / $total) * 100, 1)
        $col = if ($pct -ge 90) { "Green" } elseif ($pct -ge 70) { "Yellow" } else { "Red" }
        Write-Host "  Taux synchro : $pct %" -ForegroundColor $col
    }

    # Export
    $auditPath = Join-Path $PSScriptRoot "Rapports\Audit_Sync_$(Get-Date -Format 'yyyyMMdd_HHmm').csv"
    $reportDir = Split-Path $auditPath -Parent
    if (-not (Test-Path $reportDir)) { New-Item -ItemType Directory -Path $reportDir -Force | Out-Null }
    $results | Export-Csv -Path $auditPath -NoTypeInformation -Delimiter ";" -Encoding UTF8
    Write-Host "Rapport : $auditPath" -ForegroundColor Cyan
}

function Show-EcoTechSecurityAudit {
    Clear-Host
    Write-Host "==============================================="
    Write-Host "         AUDIT DE SÉCURITÉ DES COMPTES         "
    Write-Host "==============================================="

    # Note : Trier par nom pour voir les 10 bloqués
    $locked = @(Search-ADAccount -LockedOut | Select-Object -First 10)
    $lockColor = if ($locked.Count -gt 0) { "Yellow" } else { "Green" }
    Write-Host "`n[!] Comptes bloques : $($locked.Count)" -ForegroundColor $lockColor
    if ($locked) { $locked | Select-Object Name, SamAccountName | Format-Table -AutoSize | Out-Host }


    # Trier par LastLogonDate Descending pour voir les 10 derniers à avoir été actifs
    $limit = (Get-Date).AddDays(-90)
    $inactive = @(
        Get-ADUser -Filter 'Enabled -eq $true' -Properties LastLogonDate |
        Where-Object { $_.LastLogonDate -lt $limit -and $null -ne $_.LastLogonDate } |
        Sort-Object LastLogonDate | Select-Object -First 10
    )
    $inaColor = if ($inactive.Count -gt 0) { "Red" } else { "Green" }
    Write-Host "[!] Comptes inactifs (> 90j) : $($inactive.Count)" -ForegroundColor $inaColor
    if ($inactive) { $inactive | Select-Object Name, LastLogonDate | Format-Table -AutoSize | Out-Host }

    Write-EcoLog -Message "Audit Top 10 généré." -Level Info
}

#endregion

#region 4. OFFBOARDING

function Disable-EcoTechUser {
    param([string]$SamAccountName)
    
    $config = Get-EcoTechConfig
    $date = Get-Date -Format "dd/MM/yyyy"
    $domainDN = $config.DomainInfo.DN
    $archiveOU = "OU=ARCHIVES,$domainDN"

    try {
        # 1. Vérifier si l'utilisateur existe
        $user = Get-ADUser -Identity $SamAccountName -ErrorAction Stop

        # 2. Sécurité : Vérifier si l'OU ARCHIVES existe, sinon la créer
        if (-not (Get-ADOrganizationalUnit -Filter "Name -eq 'ARCHIVES'" -SearchBase $domainDN -ErrorAction SilentlyContinue)) {
            New-ADOrganizationalUnit -Name "ARCHIVES" -Path $domainDN -Description "Comptes desactives"
            Write-EcoLog -Message "OU ARCHIVES creee." -Level Info
        }

        # 3. Déverrouiller l'objet pour permettre le déplacement (évite l'erreur Access Denied)
        Set-ADObject -Identity $user.DistinguishedName -ProtectedFromAccidentalDeletion $false

        # 4. Désactivation du compte et mise à jour de la description
        Disable-ADAccount -Identity $SamAccountName
        Set-ADUser -Identity $SamAccountName -Description "PARTI LE $date"

        # 5. Déplacement vers l'OU ARCHIVES
        Move-ADObject -Identity $user.DistinguishedName -TargetPath $archiveOU
        
        Write-EcoLog -Message "Utilisateur $SamAccountName archivé avec succès le $date (Déplacé dans OU=ARCHIVES)" -Level Warning

    } catch {
        Write-EcoLog -Message "Erreur lors de l'archivage de $SamAccountName : $($_.Exception.Message)" -Level Error
    }
}

#endregion

#region 4. INTERFACE

function Show-UserMenu {
    do {
        Clear-Host
        Write-Host "================================================"
        Write-Host "           GESTION DES UTILISATEURS             "
        Write-Host "================================================"
        if (Get-Command Show-EcoTechStatus -ErrorAction SilentlyContinue) { Show-EcoTechStatus }
        Write-Host ""
        Write-Host "1. Importation complète (CSV)"
        Write-Host "2. Synchroniser (Managers & Groupes)"
        Write-Host "3. Audit de cohérence (CSV vs AD)"
        Write-Host "4. Audit de Sécurité"
        Write-Host "5. Archivage d'un utilisateur"
        Write-Host "6. Déverrouiller un compte utilisateur"
        Write-Host "Q. Retour"
        
        $c = Read-Host "`nChoix"
        switch ($c) {
            '1' {
                Clear-Host
                $p = Read-Host "Fichier CSV (Entree pour Fiche_personnels.csv)"
                if ([string]::IsNullOrWhiteSpace($p)) { $p = "Fiche_personnels.csv" }
                $up = Read-Host "Mettre a jour l'existant ? (O/N)"
                Import-EcoTechUsers -CSVPath $p -UpdateExisting:($up -eq 'O')
                Pause
            }
            '2' {
                Clear-Host
                Sync-EcoTechManagers
                Invoke-EcoTechGroupSync
                Pause
            }
            '3' { Clear-Host; Compare-EcoTechSync; Pause }
            '4' { Clear-Host; Show-EcoTechSecurityAudit; Pause }
            '5' {
                Clear-Host
                $s = Read-Host "SamAccountName a archiver"
                if ($s) { Disable-EcoTechUser -SamAccountName $s }
                Pause
            }
            '6' {
                Clear-Host
                $sam = Read-Host "SamAccountName a deverrouiller"
                if ($sam) {
                    try {
                        Unlock-ADAccount -Identity $sam -ErrorAction Stop
                        Write-EcoLog -Message "Compte $sam deverrouille." -Level Success
                    } catch {
                        Write-EcoLog -Message "Erreur deverrouillage $sam : $($_.Exception.Message)" -Level Error
                    }
                }
                Pause
            }
        }
    } while ($c -ne 'Q')
}

#endregion

# Exporter toutes les fonctions pour qu'elles soient visibles
Export-ModuleMember -Function @(
    'Import-EcoTechUsers',
    'Sync-EcoTechManagers',
    'Invoke-EcoTechGroupSync',
    'Compare-EcoTechSync',
    'Show-EcoTechSecurityAudit',
    'Disable-EcoTechUser',
    'Show-UserMenu'
)
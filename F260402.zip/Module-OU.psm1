<#
.SYNOPSIS
    Module de gestion des OUs.

.NOTES
    Auteur: Équipe G2
#>

if (-not (Get-Module Module-Common)) {
    Import-Module "$PSScriptRoot\Module-Common.psm1" -ErrorAction Stop
}

function New-EcoTechOUStructure {
    [CmdletBinding(SupportsShouldProcess=$true)]
    param()
    
    Write-EcoLog -Message "Vérification et mise à jour de l'arborescence OU..." -Level Info
    
    try {
        $config = Get-EcoTechConfig
        $domainDN = $config.DomainInfo.DN
        
        $created = 0
        $updated = 0
        $totalOUs = $config.OUStructure.Count
        
        $i = 0
        foreach ($ou in $config.OUStructure) {
            $i++
            # Affichage de la progression en "arrière-plan"
            Write-Progress -Activity "Configuration des OUs" `
                           -Status "Traitement de : $($ou.Name)" `
                           -PercentComplete (($i / $totalOUs) * 100)

            $Path = if ([string]::IsNullOrWhiteSpace($ou.Parent)) { $domainDN } else { "$($ou.Parent),$domainDN" }
            
            # Recherche de l'OU existante (au niveau spécifié uniquement)
            $existing = Get-ADOrganizationalUnit -Filter "Name -eq '$($ou.Name)'" -SearchBase $Path -SearchScope OneLevel -ErrorAction SilentlyContinue

            if ($existing) {
                # L'OU existe : mise à jour de la description si différente
                if ($existing.Description -ne $ou.Description) {
                    Set-ADOrganizationalUnit -Identity $existing.DistinguishedName -Description $ou.Description
                    $updated++
                }
            } else {
                # L'OU n'existe pas : création
                if ($PSCmdlet.ShouldProcess("$($ou.Name)", "Créer l'OU")) {
                    New-ADOrganizationalUnit -Name $ou.Name -Path $Path -Description $ou.Description
                    Write-EcoLog -Message "OU Créée : $($ou.Name)" -Level Success
                    $created++
                }
            }
        }
        
        # Bilan final affiché à l'écran
        Write-Progress -Activity "Configuration des OUs" -Completed
        Write-Host ""
        Write-Host "=== BILAN INFRASTRUCTURE ==="
        Write-Host "  OUs créées      : $created"
        Write-Host "  OUs mises à jour : $updated"
        Write-Host "  Total traitées  : $totalOUs"
        
    } catch {
        Write-EcoLog -Message "Erreur OU Structure : $($_.Exception.Message)" -Level Error
    }
}

function Remove-EcoTechEntireInfrastructure {
    [CmdletBinding(SupportsShouldProcess=$true)]
    param()
    
    Write-Host "ATTENTION : Suppression totale de l'infrastructure en cours..." -ForegroundColor Red
    $confirm = Read-Host "Confirmez-vous la suppression ? (OUI pour confirmer)"
    
    if ($confirm -ne "OUI") {
        Write-Host "Action annulee."
        return
    }
        
    $racines = @("ECOTECH", "UBIHARD", "STUDIODLIGHT")
    foreach ($name in $racines) {
        $ou = Get-ADOrganizationalUnit -Filter "Name -eq '$name'" -ErrorAction SilentlyContinue
        if ($ou) {
            try {
                # Déverrouiller la protection contre la suppression
                Write-Host "Deverrouillage recursif de $name..." -ForegroundColor Gray
                Get-ADOrganizationalUnit -SearchBase $ou.DistinguishedName -Filter * -ErrorAction SilentlyContinue |
                    Set-ADObject -ProtectedFromAccidentalDeletion $false -ErrorAction SilentlyContinue
                    
                # Suppression récursive (inclut tout le contenu)
                Write-Host "Suppression de $name..."
                Remove-ADOrganizationalUnit -Identity $ou.DistinguishedName -Recursive -Confirm:$false
                Write-EcoLog -Message "Infrastructure $name supprimée." -Level Warning
            } catch {
                Write-EcoLog -Message "Erreur suppression $name : $($_.Exception.Message)" -Level Error
            }
        }
    }
}


function Show-OUMenu {
    do {
        Clear-Host
        Write-Host "=== GESTION OU ==="
        Write-Host "1. Initialiser/Mettre à jour toute l'infrastructure "
        Write-Host "2. [DANGER] Supprimer toute l'infrastructure" -ForegroundColor Red
        Write-Host "Q. Retour"
        
        $c = Read-Host "`nChoix"
        
        switch ($c) {
            '1' { New-EcoTechOUStructure; Pause }
            '2' { Remove-EcoTechEntireInfrastructure; Pause }
        }
    } while ($c -ne 'Q')
}

# Exporter toutes les fonctions pour qu'elles soient visibles
Export-ModuleMember -Function @(
	'New-EcoTechOUStructure',
	'Remove-EcoTechEntireInfrastructure',
	'Show-OUMenu'
)
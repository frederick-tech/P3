<#
.SYNOPSIS
    Module de gestion des Ordinateurs.

.DESCRIPTION
    Gere la creation des objets ordinateur dans l'AD.
    Placement dynamique selon le type de poste (BX/CX/EX/FX).
    
.NOTES
    Auteur: Équipe G2
#>

if (-not (Get-Module Module-Common)) {
    Import-Module "$PSScriptRoot\Module-Common.psm1" -ErrorAction Stop
}

function Import-EcoTechComputers {
    param([string]$CSVPath)

    if (-not (Test-Path $CSVPath)) {
        Write-EcoLog -Message "Fichier CSV introuvable : $CSVPath" -Level Error
        return
    }

    $config = Get-EcoTechConfig
    $delim = if ($config.CSVDelimiter) { $config.CSVDelimiter } else { "," }
    $dn = $config.DomainInfo.DN
    $rows = Import-Csv $CSVPath -Delimiter $delim -Encoding UTF8

    $created = 0
    $errors  = 0

    foreach ($row in $rows) {
        $ComputerName = $row.'Nom de PC'

        if ([string]::IsNullOrWhiteSpace($ComputerName)) {
            Write-EcoLog -Message "Nom de PC vide, ligne ignoree." -Level Warning
            continue
        }

        # Detection dynamique du type si colonne "Type" presente
        $TypeOU = "CX"
        if ($row.PSObject.Properties.Name -contains "Type") {
            $TypeOU = switch -Wildcard ($row.Type) {
                "*Fixe*"      { "BX" }
                "*Portable*"  { "CX" }
                Default       { "CX" }
            }
        }

			# Détermination dynamique de l'emplacement du PC (Société / Site)
			$RootOU = switch -Wildcard ($row.Societe) { 
			    "*UBIHard*"       { "UBIHARD" } 
			    "*Studio Dlight*" { "STUDIODLIGHT" } 
			    Default           { "ECOTECH" } 
			}
			$SiteOU = switch -Wildcard ($row.Site) { 
			    "*Paris*"  { "PAR" } 
			    "*Nantes*" { "NTE" } 
			    Default    { "BDX" } 
			}
			# Chemin final : Type (BX/CX) -> WX -> Site -> Société
			$TargetOU = "OU=$TypeOU,OU=WX,OU=$SiteOU,OU=$RootOU,$dn"

        $Desc = "PC"
        if ($row.Prenom -and $row.Nom) {
            $Desc = "PC de $($row.Prenom) $($row.Nom)"
        }

        try {
            $existing = Get-ADComputer -Filter "Name -eq '$ComputerName'" -ErrorAction SilentlyContinue

            if (-not $existing) {
                New-ADComputer -Name $ComputerName -Path $TargetOU -Description $Desc
                Write-EcoLog -Message "PC Cree : $ComputerName -> $TypeOU" -Level Success
                $created++
            } else {
                Write-EcoLog -Message "PC existe deja : $ComputerName" -Level Warning
            }
        } catch {
            Write-EcoLog -Message "Erreur PC $ComputerName : $($_.Exception.Message)" -Level Error
            $errors++
        }
    }

    Write-EcoLog -Message "=== BILAN PC : $created crees | $errors erreurs ===" -Level Info
}

function Show-ComputerMenu {
    Clear-Host
    Write-Host "=== GESTION ORDINATEURS (WX) ==="
    Write-Host "1. Import CSV"
    Write-Host "Q. Retour"
    $c = Read-Host "Choix"
    if ($c -eq '1') { 
        $p = Read-Host "Chemin CSV"
        Import-EcoTechComputers -CSVPath $p
        Pause 
    }
}

# Exporter toutes les fonctions pour qu'elles soient visibles
Export-ModuleMember -Function @(
	'Import-EcoTechComputers',
	'Show-ComputerMenu'
)